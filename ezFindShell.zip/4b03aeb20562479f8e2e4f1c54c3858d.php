<?php

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

for ($i = 1; $i <= 10; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

$data = array("ftWGEZOS" => "value1", "ianBbSaJ" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded ftWGEZOS: " . $decoded["ftWGEZOS"] . "\n";

$cSOXZlry = rand(1, 100);
if ($cSOXZlry % 2 == 0) {
    echo "$cSOXZlry is even.\n";
} else {
    echo "$cSOXZlry is odd.\n";
}

$fotPwYzL = rand(1, 100);
if ($fotPwYzL % 2 == 0) {
    echo "$fotPwYzL is even.\n";
} else {
    echo "$fotPwYzL is odd.\n";
}

?>