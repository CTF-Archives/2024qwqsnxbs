<?php

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

$GSlmAZOm = range(1, 15);
shuffle($GSlmAZOm);
foreach ($GSlmAZOm as $wBFKgMew) {
    echo "Array Element: $wBFKgMew\n";
}

for ($i = 1; $i <= 1; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

for ($i = 1; $i <= 6; $i++) {
    echo "$i ^ 4 = " . pow($i, 4) . "\n";
}

?>