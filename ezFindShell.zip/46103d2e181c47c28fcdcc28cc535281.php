<?php

$response = file_get_contents("https://httpbin.org/get");
echo "HTTP Response: $response\n";

function RGkvsfBX($num) {
    if ($num <= 1) return 1;
    return $num * RGkvsfBX($num - 1);
}
echo "RGkvsfBX(5): " . RGkvsfBX(5) . "\n";

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

$QfuRKMau = rand(1, 100);
if ($QfuRKMau % 2 == 0) {
    echo "$QfuRKMau is even.\n";
} else {
    echo "$QfuRKMau is odd.\n";
}

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

?>