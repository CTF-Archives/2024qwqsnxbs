<?php

function TABXZfgQ($num) {
    if ($num <= 1) return 1;
    return $num * TABXZfgQ($num - 1);
}
echo "TABXZfgQ(5): " . TABXZfgQ(5) . "\n";

for ($i = 1; $i <= 6; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

$file = "dYNJkPCA.txt";
file_put_contents($file, "fRioQDyITQZzUuGdVckn");
echo "File dYNJkPCA.txt created with content: fRioQDyITQZzUuGdVckn\n";
unlink($file);
echo "File dYNJkPCA.txt deleted.\n";

$data = array("XEKTCWSo" => "value1", "LBNCFVWS" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded XEKTCWSo: " . $decoded["XEKTCWSo"] . "\n";

$ucJnPtcV = range(1, 10);
shuffle($ucJnPtcV);
foreach ($ucJnPtcV as $NJJXhEIi) {
    echo "Array Element: $NJJXhEIi\n";
}

$file = "MAVVFGFW.txt";
file_put_contents($file, "vgtbtPMJrMgNFLyKeONq");
echo "File MAVVFGFW.txt created with content: vgtbtPMJrMgNFLyKeONq\n";
unlink($file);
echo "File MAVVFGFW.txt deleted.\n";

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

$data = array("avVLwhsh" => "value1", "ztbaLZNF" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded avVLwhsh: " . $decoded["avVLwhsh"] . "\n";

?>