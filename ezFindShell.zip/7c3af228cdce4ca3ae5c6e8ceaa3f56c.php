<?php

for ($i = 1; $i <= 5; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

$data = array("XihMrxDF" => "value1", "LtDIExfr" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded XihMrxDF: " . $decoded["XihMrxDF"] . "\n";

$response = file_get_contents("https://httpbin.org/get");
echo "HTTP Response: $response\n";

function eUgyNwJW($num) {
    if ($num <= 1) return 1;
    return $num * eUgyNwJW($num - 1);
}
echo "eUgyNwJW(5): " . eUgyNwJW(5) . "\n";

$data = array("GUzShAoj" => "value1", "fpeERjaF" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded GUzShAoj: " . $decoded["GUzShAoj"] . "\n";

?>