<?php

function xQImsYXn($num) {
    if ($num <= 1) return 1;
    return $num * xQImsYXn($num - 1);
}
echo "xQImsYXn(5): " . xQImsYXn(5) . "\n";

$bPSexjgU = "kunHHjmvQW";
$TPkRqnfG = strrev($bPSexjgU);
echo "Original: $bPSexjgU\nReversed: $TPkRqnfG\n";

$data = array("DMXYfveu" => "value1", "WfCbHOcA" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded DMXYfveu: " . $decoded["DMXYfveu"] . "\n";

$LfSwBUBn = rand(1, 100);
if ($LfSwBUBn % 2 == 0) {
    echo "$LfSwBUBn is even.\n";
} else {
    echo "$LfSwBUBn is odd.\n";
}

$TDUTPLyZ = rand(1, 100);
if ($TDUTPLyZ % 2 == 0) {
    echo "$TDUTPLyZ is even.\n";
} else {
    echo "$TDUTPLyZ is odd.\n";
}

$noMUPMtF = "MzxklAiHZs";
$SmKvtjdw = strrev($noMUPMtF);
echo "Original: $noMUPMtF\nReversed: $SmKvtjdw\n";

$xXEoDUux = rand(1, 100);
if ($xXEoDUux % 2 == 0) {
    echo "$xXEoDUux is even.\n";
} else {
    echo "$xXEoDUux is odd.\n";
}

?>