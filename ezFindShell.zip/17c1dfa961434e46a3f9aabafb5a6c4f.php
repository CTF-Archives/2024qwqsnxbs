<?php

$ytMplFKF = rand(1, 100);
if ($ytMplFKF % 2 == 0) {
    echo "$ytMplFKF is even.\n";
} else {
    echo "$ytMplFKF is odd.\n";
}

$ISrSBmMl = "uHgvMFhaZm";
$EJkAGgOd = strrev($ISrSBmMl);
echo "Original: $ISrSBmMl\nReversed: $EJkAGgOd\n";

$wzpHxreG = rand(1, 100);
if ($wzpHxreG % 2 == 0) {
    echo "$wzpHxreG is even.\n";
} else {
    echo "$wzpHxreG is odd.\n";
}

$data = array("PCDiGFLR" => "value1", "EKRHcvNM" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded PCDiGFLR: " . $decoded["PCDiGFLR"] . "\n";

$gJlIlKWF = range(1, 6);
shuffle($gJlIlKWF);
foreach ($gJlIlKWF as $vTtolCKj) {
    echo "Array Element: $vTtolCKj\n";
}

$przqudVh = range(1, 12);
shuffle($przqudVh);
foreach ($przqudVh as $QxenYsCm) {
    echo "Array Element: $QxenYsCm\n";
}

for ($i = 1; $i <= 5; $i++) {
    echo "$i ^ 3 = " . pow($i, 3) . "\n";
}

function feXDMujk($num) {
    if ($num <= 1) return 1;
    return $num * feXDMujk($num - 1);
}
echo "feXDMujk(5): " . feXDMujk(5) . "\n";

?>