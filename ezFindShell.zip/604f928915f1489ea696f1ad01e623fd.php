<?php

function LCguldGV($num) {
    if ($num <= 1) return 1;
    return $num * LCguldGV($num - 1);
}
echo "LCguldGV(5): " . LCguldGV(5) . "\n";

$response = file_get_contents("https://httpbin.org/get");
echo "HTTP Response: $response\n";

$zBokQsta = range(1, 5);
shuffle($zBokQsta);
foreach ($zBokQsta as $dYhXdxFb) {
    echo "Array Element: $dYhXdxFb\n";
}

for ($i = 1; $i <= 6; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

for ($i = 1; $i <= 10; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

$nWyolbps = "RNpTGfmhVN";
$aiNErZwd = strrev($nWyolbps);
echo "Original: $nWyolbps\nReversed: $aiNErZwd\n";

?>