<?php

class WkqQwtPv {
    public function mSthEtQP($message) {
        echo "Message: $message\n";
    }
}
$obj = new WkqQwtPv();
$obj->mSthEtQP("Hello from WkqQwtPv");

for ($i = 1; $i <= 6; $i++) {
    echo "$i ^ 4 = " . pow($i, 4) . "\n";
}

function VQDRPlNa($num) {
    if ($num <= 1) return 1;
    return $num * VQDRPlNa($num - 1);
}
echo "VQDRPlNa(5): " . VQDRPlNa(5) . "\n";

for ($i = 1; $i <= 5; $i++) {
    echo "$i ^ 4 = " . pow($i, 4) . "\n";
}

$file = "yXPcDRVc.txt";
file_put_contents($file, "hqQKCJTSPfESYpwGAzfj");
echo "File yXPcDRVc.txt created with content: hqQKCJTSPfESYpwGAzfj\n";
unlink($file);
echo "File yXPcDRVc.txt deleted.\n";

?>