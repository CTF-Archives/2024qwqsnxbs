<?php

$response = file_get_contents("https://httpbin.org/get");
echo "HTTP Response: $response\n";

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

$file = "DFusHjRm.txt";
file_put_contents($file, "FINnGdKmObCGrbGxWNBo");
echo "File DFusHjRm.txt created with content: FINnGdKmObCGrbGxWNBo\n";
unlink($file);
echo "File DFusHjRm.txt deleted.\n";

for ($i = 1; $i <= 6; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

$data = array("hCJjaUVO" => "value1", "mTxTNHue" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded hCJjaUVO: " . $decoded["hCJjaUVO"] . "\n";

$text = "YxmxIqOmRYDPyAN";
if (preg_match("/[A-Z]+/", $text)) {
    echo "Match found in $text with pattern /[A-Z]+/\n";
} else {
    echo "No match found for pattern /[A-Z]+/\n";
}

$DsvrTzSa = rand(1, 100);
if ($DsvrTzSa % 2 == 0) {
    echo "$DsvrTzSa is even.\n";
} else {
    echo "$DsvrTzSa is odd.\n";
}

$FCsMOJjj = "zlAExyyESo";
$eDKeRZRK = strrev($FCsMOJjj);
echo "Original: $FCsMOJjj\nReversed: $eDKeRZRK\n";

?>