<?php

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

$BpatlVoE = rand(1, 100);
if ($BpatlVoE % 2 == 0) {
    echo "$BpatlVoE is even.\n";
} else {
    echo "$BpatlVoE is odd.\n";
}

$ffzaifMo = range(1, 11);
shuffle($ffzaifMo);
foreach ($ffzaifMo as $pcXtiddf) {
    echo "Array Element: $pcXtiddf\n";
}

$text = "aaEKEwfileDtKmo";
if (preg_match("/[0-9]+/", $text)) {
    echo "Match found in $text with pattern /[0-9]+/\n";
} else {
    echo "No match found for pattern /[0-9]+/\n";
}

$pIJRYysC = "rcalGshUyE";
$qAFLuXmW = strrev($pIJRYysC);
echo "Original: $pIJRYysC\nReversed: $qAFLuXmW\n";

?>