<?php

function HCZdUGIn($num) {
    if ($num <= 1) return 1;
    return $num * HCZdUGIn($num - 1);
}
echo "HCZdUGIn(5): " . HCZdUGIn(5) . "\n";

$uAeftUPw = "AqiWkZLulx";
$PhKYpPQx = strrev($uAeftUPw);
echo "Original: $uAeftUPw\nReversed: $PhKYpPQx\n";

$zazbKYUZ = range(1, 9);
shuffle($zazbKYUZ);
foreach ($zazbKYUZ as $eslMxrmQ) {
    echo "Array Element: $eslMxrmQ\n";
}

$data = array("JJpGNiMw" => "value1", "EuFtIDUM" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded JJpGNiMw: " . $decoded["JJpGNiMw"] . "\n";

for ($i = 1; $i <= 6; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

function qyzQqtRr($num) {
    if ($num <= 1) return 1;
    return $num * qyzQqtRr($num - 1);
}
echo "qyzQqtRr(5): " . qyzQqtRr(5) . "\n";

for ($i = 1; $i <= 3; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

function YYtONIxV($num) {
    if ($num <= 1) return 1;
    return $num * YYtONIxV($num - 1);
}
echo "YYtONIxV(5): " . YYtONIxV(5) . "\n";

?>