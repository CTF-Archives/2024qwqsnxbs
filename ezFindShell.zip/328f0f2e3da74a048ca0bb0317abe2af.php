<?php

$data = array("NsRgGIwy" => "value1", "GQFqasNG" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded NsRgGIwy: " . $decoded["NsRgGIwy"] . "\n";

$file = "hneBxINn.txt";
file_put_contents($file, "QNakzdNmWfbDyRreAUkn");
echo "File hneBxINn.txt created with content: QNakzdNmWfbDyRreAUkn\n";
unlink($file);
echo "File hneBxINn.txt deleted.\n";

$file = "YKaBrVrp.txt";
file_put_contents($file, "jYRHkcdeJrajLZdTrWhI");
echo "File YKaBrVrp.txt created with content: jYRHkcdeJrajLZdTrWhI\n";
unlink($file);
echo "File YKaBrVrp.txt deleted.\n";

function ppmWJbIz($num) {
    if ($num <= 1) return 1;
    return $num * ppmWJbIz($num - 1);
}
echo "ppmWJbIz(5): " . ppmWJbIz(5) . "\n";

$KxibBQWz = "oRqsBKnKQh";
$wdpUImLx = strrev($KxibBQWz);
echo "Original: $KxibBQWz\nReversed: $wdpUImLx\n";

$yZPjOHLv = range(1, 5);
shuffle($yZPjOHLv);
foreach ($yZPjOHLv as $ISPjXnvU) {
    echo "Array Element: $ISPjXnvU\n";
}

?>