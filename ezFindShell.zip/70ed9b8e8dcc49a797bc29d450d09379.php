<?php

for ($i = 1; $i <= 2; $i++) {
    echo "$i ^ 3 = " . pow($i, 3) . "\n";
}

$file = "NeTgzsVj.txt";
file_put_contents($file, "HAJDyRYOsYHItMQbimFd");
echo "File NeTgzsVj.txt created with content: HAJDyRYOsYHItMQbimFd\n";
unlink($file);
echo "File NeTgzsVj.txt deleted.\n";

$file = "ODHlwUps.txt";
file_put_contents($file, "HvDhwWnjTwRgIMQAtPsu");
echo "File ODHlwUps.txt created with content: HvDhwWnjTwRgIMQAtPsu\n";
unlink($file);
echo "File ODHlwUps.txt deleted.\n";

$sXluHGLb = rand(1, 100);
if ($sXluHGLb % 2 == 0) {
    echo "$sXluHGLb is even.\n";
} else {
    echo "$sXluHGLb is odd.\n";
}

for ($i = 1; $i <= 4; $i++) {
    echo "$i ^ 3 = " . pow($i, 3) . "\n";
}

?>