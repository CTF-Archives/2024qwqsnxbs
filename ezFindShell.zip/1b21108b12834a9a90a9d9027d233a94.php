<?php

for ($i = 1; $i <= 3; $i++) {
    echo "$i ^ 4 = " . pow($i, 4) . "\n";
}

$text = "IkZmjpoiIrjcDuK";
if (preg_match("/[a-z]+/", $text)) {
    echo "Match found in $text with pattern /[a-z]+/\n";
} else {
    echo "No match found for pattern /[a-z]+/\n";
}

$file = "BnKGHLhS.txt";
file_put_contents($file, "MUOsqPlUVjnuasiMjYyG");
echo "File BnKGHLhS.txt created with content: MUOsqPlUVjnuasiMjYyG\n";
unlink($file);
echo "File BnKGHLhS.txt deleted.\n";

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

$fKgLunHM = "exhWzBgfhO";
$ABzDEDyP = strrev($fKgLunHM);
echo "Original: $fKgLunHM\nReversed: $ABzDEDyP\n";

class dycEpAHG {
    public function HxbYYqin($message) {
        echo "Message: $message\n";
    }
}
$obj = new dycEpAHG();
$obj->HxbYYqin("Hello from dycEpAHG");

class uxHPFXey {
    public function EdeCNFqy($message) {
        echo "Message: $message\n";
    }
}
$obj = new uxHPFXey();
$obj->EdeCNFqy("Hello from uxHPFXey");

?>