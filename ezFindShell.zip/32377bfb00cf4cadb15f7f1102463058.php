<?php

$eWSqeVan = rand(1, 100);
if ($eWSqeVan % 2 == 0) {
    echo "$eWSqeVan is even.\n";
} else {
    echo "$eWSqeVan is odd.\n";
}

$znvnJxSo = rand(1, 100);
if ($znvnJxSo % 2 == 0) {
    echo "$znvnJxSo is even.\n";
} else {
    echo "$znvnJxSo is odd.\n";
}

$VnnZORib = rand(1, 100);
if ($VnnZORib % 2 == 0) {
    echo "$VnnZORib is even.\n";
} else {
    echo "$VnnZORib is odd.\n";
}

function LxygCoFt($num) {
    if ($num <= 1) return 1;
    return $num * LxygCoFt($num - 1);
}
echo "LxygCoFt(5): " . LxygCoFt(5) . "\n";

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

$response = file_get_contents("https://httpbin.org/get");
echo "HTTP Response: $response\n";

?>