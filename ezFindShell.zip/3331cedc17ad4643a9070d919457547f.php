<?php

$data = array("NQobKAyN" => "value1", "pVNgDBcY" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded NQobKAyN: " . $decoded["NQobKAyN"] . "\n";

$wQAUMsqo = range(1, 14);
shuffle($wQAUMsqo);
foreach ($wQAUMsqo as $zXhyGNaa) {
    echo "Array Element: $zXhyGNaa\n";
}

$kDgVFbIs = rand(1, 100);
if ($kDgVFbIs % 2 == 0) {
    echo "$kDgVFbIs is even.\n";
} else {
    echo "$kDgVFbIs is odd.\n";
}

function gUslyvNI($num) {
    if ($num <= 1) return 1;
    return $num * gUslyvNI($num - 1);
}
echo "gUslyvNI(5): " . gUslyvNI(5) . "\n";

$VgPwUGgc = "mBTyobffev";
$ajbZYTMu = strrev($VgPwUGgc);
echo "Original: $VgPwUGgc\nReversed: $ajbZYTMu\n";

$fgqGGNAK = rand(1, 100);
if ($fgqGGNAK % 2 == 0) {
    echo "$fgqGGNAK is even.\n";
} else {
    echo "$fgqGGNAK is odd.\n";
}

$frkwCeGE = "rzsxUkglBr";
$ynCRxpPm = strrev($frkwCeGE);
echo "Original: $frkwCeGE\nReversed: $ynCRxpPm\n";

?>