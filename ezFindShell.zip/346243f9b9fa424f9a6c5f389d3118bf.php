<?php

$text = "GAvhRDrYHxqZZMA";
if (preg_match("/[a-z]+/", $text)) {
    echo "Match found in $text with pattern /[a-z]+/\n";
} else {
    echo "No match found for pattern /[a-z]+/\n";
}

for ($i = 1; $i <= 5; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

for ($i = 1; $i <= 3; $i++) {
    echo "$i ^ 3 = " . pow($i, 3) . "\n";
}

$response = file_get_contents("https://httpbin.org/get");
echo "HTTP Response: $response\n";

$UOlOjBpB = rand(1, 100);
if ($UOlOjBpB % 2 == 0) {
    echo "$UOlOjBpB is even.\n";
} else {
    echo "$UOlOjBpB is odd.\n";
}

?>