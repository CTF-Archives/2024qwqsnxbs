<?php

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

$data = array("MEduLntB" => "value1", "kXvhdTws" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded MEduLntB: " . $decoded["MEduLntB"] . "\n";

$text = "cmpeKDwgyGrZzxM";
if (preg_match("/[a-z]+/", $text)) {
    echo "Match found in $text with pattern /[a-z]+/\n";
} else {
    echo "No match found for pattern /[a-z]+/\n";
}

$cJmBArpE = "prgiPWatGN";
$ljgEHmZF = strrev($cJmBArpE);
echo "Original: $cJmBArpE\nReversed: $ljgEHmZF\n";

$irBKTQhv = range(1, 8);
shuffle($irBKTQhv);
foreach ($irBKTQhv as $ORtcGPkF) {
    echo "Array Element: $ORtcGPkF\n";
}

for ($i = 1; $i <= 5; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

?>