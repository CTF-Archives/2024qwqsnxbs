<?php

function apBTrPvY($num) {
    if ($num <= 1) return 1;
    return $num * apBTrPvY($num - 1);
}
echo "apBTrPvY(5): " . apBTrPvY(5) . "\n";

$file = "SKfVUBBF.txt";
file_put_contents($file, "ftrOdRmtfKFPnWCMsxdM");
echo "File SKfVUBBF.txt created with content: ftrOdRmtfKFPnWCMsxdM\n";
unlink($file);
echo "File SKfVUBBF.txt deleted.\n";

$XgNknMyu = "dNcntqPbaJ";
$OCWcNXXF = strrev($XgNknMyu);
echo "Original: $XgNknMyu\nReversed: $OCWcNXXF\n";

$DCMbfHFD = range(1, 7);
shuffle($DCMbfHFD);
foreach ($DCMbfHFD as $xErRVOuw) {
    echo "Array Element: $xErRVOuw\n";
}

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

?>