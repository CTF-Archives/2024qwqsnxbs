<?php

function yGTPfVej($num) {
    if ($num <= 1) return 1;
    return $num * yGTPfVej($num - 1);
}
echo "yGTPfVej(5): " . yGTPfVej(5) . "\n";

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

$PuuFDJsr = "WJkRiiNhCm";
$uffRDkhd = strrev($PuuFDJsr);
echo "Original: $PuuFDJsr\nReversed: $uffRDkhd\n";

$file = "nMdGYgIR.txt";
file_put_contents($file, "lGkIWNjYKJQaXKbKpqWf");
echo "File nMdGYgIR.txt created with content: lGkIWNjYKJQaXKbKpqWf\n";
unlink($file);
echo "File nMdGYgIR.txt deleted.\n";

$QEtIzBAk = "KpSuMJacVY";
$hrdfwzYw = strrev($QEtIzBAk);
echo "Original: $QEtIzBAk\nReversed: $hrdfwzYw\n";

?>