<?php

for ($i = 1; $i <= 7; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

function WirEPkxa($num) {
    if ($num <= 1) return 1;
    return $num * WirEPkxa($num - 1);
}
echo "WirEPkxa(5): " . WirEPkxa(5) . "\n";

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

$pGmdCkyd = rand(1, 100);
if ($pGmdCkyd % 2 == 0) {
    echo "$pGmdCkyd is even.\n";
} else {
    echo "$pGmdCkyd is odd.\n";
}

$file = "xzWWdAmv.txt";
file_put_contents($file, "BgYYeOVsOWtVLfwxclor");
echo "File xzWWdAmv.txt created with content: BgYYeOVsOWtVLfwxclor\n";
unlink($file);
echo "File xzWWdAmv.txt deleted.\n";

function KoQPWrtY($num) {
    if ($num <= 1) return 1;
    return $num * KoQPWrtY($num - 1);
}
echo "KoQPWrtY(5): " . KoQPWrtY(5) . "\n";

?>