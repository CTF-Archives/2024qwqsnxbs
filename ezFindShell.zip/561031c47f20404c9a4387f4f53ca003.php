<?php

$text = "LygCnMlXxfWUFxY";
if (preg_match("/[a-z]+/", $text)) {
    echo "Match found in $text with pattern /[a-z]+/\n";
} else {
    echo "No match found for pattern /[a-z]+/\n";
}

function OtafQHTy($num) {
    if ($num <= 1) return 1;
    return $num * OtafQHTy($num - 1);
}
echo "OtafQHTy(5): " . OtafQHTy(5) . "\n";

for ($i = 1; $i <= 4; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

class MoFigxXk {
    public function LDhkoEDj($message) {
        echo "Message: $message\n";
    }
}
$obj = new MoFigxXk();
$obj->LDhkoEDj("Hello from MoFigxXk");

$guyPmlzl = rand(1, 100);
if ($guyPmlzl % 2 == 0) {
    echo "$guyPmlzl is even.\n";
} else {
    echo "$guyPmlzl is odd.\n";
}

$vSHMeruz = rand(1, 100);
if ($vSHMeruz % 2 == 0) {
    echo "$vSHMeruz is even.\n";
} else {
    echo "$vSHMeruz is odd.\n";
}

$file = "mgKJozjs.txt";
file_put_contents($file, "gHKvrcTgrFuGwgKCrtGS");
echo "File mgKJozjs.txt created with content: gHKvrcTgrFuGwgKCrtGS\n";
unlink($file);
echo "File mgKJozjs.txt deleted.\n";

?>