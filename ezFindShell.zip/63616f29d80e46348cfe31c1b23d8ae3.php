<?php

$SsVWDsou = "SPwlFNrrbX";
$ZBrueXMB = strrev($SsVWDsou);
echo "Original: $SsVWDsou\nReversed: $ZBrueXMB\n";

$text = "tPCobRXZDLjIKoL";
if (preg_match("/[A-Z]+/", $text)) {
    echo "Match found in $text with pattern /[A-Z]+/\n";
} else {
    echo "No match found for pattern /[A-Z]+/\n";
}

for ($i = 1; $i <= 10; $i++) {
    echo "$i ^ 3 = " . pow($i, 3) . "\n";
}

function dAMrcpZa($num) {
    if ($num <= 1) return 1;
    return $num * dAMrcpZa($num - 1);
}
echo "dAMrcpZa(5): " . dAMrcpZa(5) . "\n";

for ($i = 1; $i <= 9; $i++) {
    echo "$i ^ 4 = " . pow($i, 4) . "\n";
}

?>