<?php

$file = "zGFsJAmO.txt";
file_put_contents($file, "WynWDRLLzTVOnXcSkPZe");
echo "File zGFsJAmO.txt created with content: WynWDRLLzTVOnXcSkPZe\n";
unlink($file);
echo "File zGFsJAmO.txt deleted.\n";

function BElztPCs($num) {
    if ($num <= 1) return 1;
    return $num * BElztPCs($num - 1);
}
echo "BElztPCs(5): " . BElztPCs(5) . "\n";

$response = file_get_contents("https://httpbin.org/get");
echo "HTTP Response: $response\n";

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

$file = "mWAqmuhD.txt";
file_put_contents($file, "PysRqxbIWDJTQAVqHBdt");
echo "File mWAqmuhD.txt created with content: PysRqxbIWDJTQAVqHBdt\n";
unlink($file);
echo "File mWAqmuhD.txt deleted.\n";

$response = file_get_contents("https://httpbin.org/get");
echo "HTTP Response: $response\n";

for ($i = 1; $i <= 5; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

?>