<?php

function MbZBGqnn($num) {
    if ($num <= 1) return 1;
    return $num * MbZBGqnn($num - 1);
}
echo "MbZBGqnn(5): " . MbZBGqnn(5) . "\n";

$text = "nxCdRuRWhmHFeUX";
if (preg_match("/[a-z]+/", $text)) {
    echo "Match found in $text with pattern /[a-z]+/\n";
} else {
    echo "No match found for pattern /[a-z]+/\n";
}

$text = "HNCGFtUdOZdxmye";
if (preg_match("/[A-Z]+/", $text)) {
    echo "Match found in $text with pattern /[A-Z]+/\n";
} else {
    echo "No match found for pattern /[A-Z]+/\n";
}

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

$wpCnLfTg = "LpXlDEZirM";
$mbwubqkc = strrev($wpCnLfTg);
echo "Original: $wpCnLfTg\nReversed: $mbwubqkc\n";

?>