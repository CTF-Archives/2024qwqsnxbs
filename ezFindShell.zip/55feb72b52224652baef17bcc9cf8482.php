<?php

$text = "XyVNOlDYfvpYHsU";
if (preg_match("/[0-9]+/", $text)) {
    echo "Match found in $text with pattern /[0-9]+/\n";
} else {
    echo "No match found for pattern /[0-9]+/\n";
}

$QIbYFCZD = rand(1, 100);
if ($QIbYFCZD % 2 == 0) {
    echo "$QIbYFCZD is even.\n";
} else {
    echo "$QIbYFCZD is odd.\n";
}

$WogyWQyf = rand(1, 100);
if ($WogyWQyf % 2 == 0) {
    echo "$WogyWQyf is even.\n";
} else {
    echo "$WogyWQyf is odd.\n";
}

for ($i = 1; $i <= 1; $i++) {
    echo "$i ^ 4 = " . pow($i, 4) . "\n";
}

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

?>