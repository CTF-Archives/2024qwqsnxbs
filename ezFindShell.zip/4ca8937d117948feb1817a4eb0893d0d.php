<?php

$response = file_get_contents("https://httpbin.org/get");
echo "HTTP Response: $response\n";

for ($i = 1; $i <= 3; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

$data = array("hQlEMGRT" => "value1", "TswQcmub" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded hQlEMGRT: " . $decoded["hQlEMGRT"] . "\n";

$file = "IqNmUNCe.txt";
file_put_contents($file, "qhsvYYayXiuYfaNYOcEr");
echo "File IqNmUNCe.txt created with content: qhsvYYayXiuYfaNYOcEr\n";
unlink($file);
echo "File IqNmUNCe.txt deleted.\n";

class FPpOygzz {
    public function kkPmNnRu($message) {
        echo "Message: $message\n";
    }
}
$obj = new FPpOygzz();
$obj->kkPmNnRu("Hello from FPpOygzz");

$file = "loiNrVTw.txt";
file_put_contents($file, "SKsiIFrQMuvXAYElsZct");
echo "File loiNrVTw.txt created with content: SKsiIFrQMuvXAYElsZct\n";
unlink($file);
echo "File loiNrVTw.txt deleted.\n";

?>