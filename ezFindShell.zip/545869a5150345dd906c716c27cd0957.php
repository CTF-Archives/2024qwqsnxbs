<?php

$data = array("iCnbmApf" => "value1", "lJZWtryX" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded iCnbmApf: " . $decoded["iCnbmApf"] . "\n";

$rJXFVtfs = rand(1, 100);
if ($rJXFVtfs % 2 == 0) {
    echo "$rJXFVtfs is even.\n";
} else {
    echo "$rJXFVtfs is odd.\n";
}

$data = array("OuGgnCXc" => "value1", "zirYTebJ" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded OuGgnCXc: " . $decoded["OuGgnCXc"] . "\n";

$HHGuCcfC = rand(1, 100);
if ($HHGuCcfC % 2 == 0) {
    echo "$HHGuCcfC is even.\n";
} else {
    echo "$HHGuCcfC is odd.\n";
}

$kEjNEhGI = rand(1, 100);
if ($kEjNEhGI % 2 == 0) {
    echo "$kEjNEhGI is even.\n";
} else {
    echo "$kEjNEhGI is odd.\n";
}

function fbwnmUNh($num) {
    if ($num <= 1) return 1;
    return $num * fbwnmUNh($num - 1);
}
echo "fbwnmUNh(5): " . fbwnmUNh(5) . "\n";

for ($i = 1; $i <= 6; $i++) {
    echo "$i ^ 3 = " . pow($i, 3) . "\n";
}

?>