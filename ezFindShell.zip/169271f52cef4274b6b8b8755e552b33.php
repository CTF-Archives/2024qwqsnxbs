<?php

$response = file_get_contents("https://httpbin.org/get");
echo "HTTP Response: $response\n";

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

$text = "suurkKFUhkisVkx";
if (preg_match("/[a-z]+/", $text)) {
    echo "Match found in $text with pattern /[a-z]+/\n";
} else {
    echo "No match found for pattern /[a-z]+/\n";
}

for ($i = 1; $i <= 5; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

$response = file_get_contents("https://httpbin.org/get");
echo "HTTP Response: $response\n";

$text = "FKyorjhrKKxYBWa";
if (preg_match("/[A-Z]+/", $text)) {
    echo "Match found in $text with pattern /[A-Z]+/\n";
} else {
    echo "No match found for pattern /[A-Z]+/\n";
}

for ($i = 1; $i <= 7; $i++) {
    echo "$i ^ 4 = " . pow($i, 4) . "\n";
}

$data = array("buPBKRDL" => "value1", "gREbKtJC" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded buPBKRDL: " . $decoded["buPBKRDL"] . "\n";

?>