<?php

$response = file_get_contents("https://httpbin.org/get");
echo "HTTP Response: $response\n";

$response = file_get_contents("https://httpbin.org/get");
echo "HTTP Response: $response\n";

$SfATvABD = "pNeiEgNsBt";
$ZiVYpMkl = strrev($SfATvABD);
echo "Original: $SfATvABD\nReversed: $ZiVYpMkl\n";

function koyezOZU($num) {
    if ($num <= 1) return 1;
    return $num * koyezOZU($num - 1);
}
echo "koyezOZU(5): " . koyezOZU(5) . "\n";

$text = "ftzjkHRZiBabrXV";
if (preg_match("/[A-Z]+/", $text)) {
    echo "Match found in $text with pattern /[A-Z]+/\n";
} else {
    echo "No match found for pattern /[A-Z]+/\n";
}

$text = "AeLbjchAkfZfBHp";
if (preg_match("/[A-Z]+/", $text)) {
    echo "Match found in $text with pattern /[A-Z]+/\n";
} else {
    echo "No match found for pattern /[A-Z]+/\n";
}

?>