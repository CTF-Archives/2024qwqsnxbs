<?php

function pijQDyFL($num) {
    if ($num <= 1) return 1;
    return $num * pijQDyFL($num - 1);
}
echo "pijQDyFL(5): " . pijQDyFL(5) . "\n";

$text = "gmXAgHBwhHzPASF";
if (preg_match("/[0-9]+/", $text)) {
    echo "Match found in $text with pattern /[0-9]+/\n";
} else {
    echo "No match found for pattern /[0-9]+/\n";
}

$text = "vdzRNvzApdXXboJ";
if (preg_match("/[a-z]+/", $text)) {
    echo "Match found in $text with pattern /[a-z]+/\n";
} else {
    echo "No match found for pattern /[a-z]+/\n";
}

$file = "ATQUjgPp.txt";
file_put_contents($file, "KZoRZFKfSvocMwOjjUau");
echo "File ATQUjgPp.txt created with content: KZoRZFKfSvocMwOjjUau\n";
unlink($file);
echo "File ATQUjgPp.txt deleted.\n";

$file = "RjYaSKRq.txt";
file_put_contents($file, "YiinAyLkGzjTGrnGZQwk");
echo "File RjYaSKRq.txt created with content: YiinAyLkGzjTGrnGZQwk\n";
unlink($file);
echo "File RjYaSKRq.txt deleted.\n";

for ($i = 1; $i <= 1; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

?>