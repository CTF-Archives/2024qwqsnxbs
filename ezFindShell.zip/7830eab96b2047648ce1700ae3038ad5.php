<?php

$EkkGEnOj = rand(1, 100);
if ($EkkGEnOj % 2 == 0) {
    echo "$EkkGEnOj is even.\n";
} else {
    echo "$EkkGEnOj is odd.\n";
}

$wtGKZsng = rand(1, 100);
if ($wtGKZsng % 2 == 0) {
    echo "$wtGKZsng is even.\n";
} else {
    echo "$wtGKZsng is odd.\n";
}

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

$file = "VxfAjjWF.txt";
file_put_contents($file, "WivcWHIYxQrGqgkvvrBV");
echo "File VxfAjjWF.txt created with content: WivcWHIYxQrGqgkvvrBV\n";
unlink($file);
echo "File VxfAjjWF.txt deleted.\n";

$data = array("kMfATVVy" => "value1", "ATiPvGoZ" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded kMfATVVy: " . $decoded["kMfATVVy"] . "\n";

?>