<?php

for ($i = 1; $i <= 6; $i++) {
    echo "$i ^ 4 = " . pow($i, 4) . "\n";
}

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

for ($i = 1; $i <= 3; $i++) {
    echo "$i ^ 4 = " . pow($i, 4) . "\n";
}

$wQlFrVbI = "niQiDXEAzM";
$eNkUKXvK = strrev($wQlFrVbI);
echo "Original: $wQlFrVbI\nReversed: $eNkUKXvK\n";

for ($i = 1; $i <= 9; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

for ($i = 1; $i <= 6; $i++) {
    echo "$i ^ 3 = " . pow($i, 3) . "\n";
}

$data = array("JCyljQhu" => "value1", "gxBAnuTS" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded JCyljQhu: " . $decoded["JCyljQhu"] . "\n";

function EoFQASDe($num) {
    if ($num <= 1) return 1;
    return $num * EoFQASDe($num - 1);
}
echo "EoFQASDe(5): " . EoFQASDe(5) . "\n";

?>