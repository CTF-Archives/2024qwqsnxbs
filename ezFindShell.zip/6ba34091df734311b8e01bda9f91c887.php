<?php

$text = "iqcjcaUWGTrGHqn";
if (preg_match("/[0-9]+/", $text)) {
    echo "Match found in $text with pattern /[0-9]+/\n";
} else {
    echo "No match found for pattern /[0-9]+/\n";
}

$text = "TrohnPtrlDSbMgc";
if (preg_match("/[A-Z]+/", $text)) {
    echo "Match found in $text with pattern /[A-Z]+/\n";
} else {
    echo "No match found for pattern /[A-Z]+/\n";
}

$data = array("qJdJOxyD" => "value1", "BEDjyHLl" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded qJdJOxyD: " . $decoded["qJdJOxyD"] . "\n";

$DwVOVWcl = "hIqCBmUzOs";
$nMcASjUO = strrev($DwVOVWcl);
echo "Original: $DwVOVWcl\nReversed: $nMcASjUO\n";

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

$WtxGOGID = "XkBUZIdMcA";
$GSbPKAgm = strrev($WtxGOGID);
echo "Original: $WtxGOGID\nReversed: $GSbPKAgm\n";

class tfqPBgaQ {
    public function MRPaQEor($message) {
        echo "Message: $message\n";
    }
}
$obj = new tfqPBgaQ();
$obj->MRPaQEor("Hello from tfqPBgaQ");

class AdFRWIgM {
    public function FOCCYFCt($message) {
        echo "Message: $message\n";
    }
}
$obj = new AdFRWIgM();
$obj->FOCCYFCt("Hello from AdFRWIgM");

?>