<?php

for ($i = 1; $i <= 10; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

$HXKKYfUz = range(1, 8);
shuffle($HXKKYfUz);
foreach ($HXKKYfUz as $RpSunMFX) {
    echo "Array Element: $RpSunMFX\n";
}

$text = "VzZNsDBayzoPzcA";
if (preg_match("/[0-9]+/", $text)) {
    echo "Match found in $text with pattern /[0-9]+/\n";
} else {
    echo "No match found for pattern /[0-9]+/\n";
}

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

$text = "VoDegQyLjDNEyvV";
if (preg_match("/[A-Z]+/", $text)) {
    echo "Match found in $text with pattern /[A-Z]+/\n";
} else {
    echo "No match found for pattern /[A-Z]+/\n";
}

for ($i = 1; $i <= 10; $i++) {
    echo "$i ^ 3 = " . pow($i, 3) . "\n";
}

for ($i = 1; $i <= 10; $i++) {
    echo "$i ^ 4 = " . pow($i, 4) . "\n";
}

?>