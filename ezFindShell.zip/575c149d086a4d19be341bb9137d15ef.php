<?php

function umfuSINw($num) {
    if ($num <= 1) return 1;
    return $num * umfuSINw($num - 1);
}
echo "umfuSINw(5): " . umfuSINw(5) . "\n";

$GvhVQraL = range(1, 9);
shuffle($GvhVQraL);
foreach ($GvhVQraL as $zRbPbatw) {
    echo "Array Element: $zRbPbatw\n";
}

$IhZPZefK = "SaJpdhjsSj";
$nETNjBBJ = strrev($IhZPZefK);
echo "Original: $IhZPZefK\nReversed: $nETNjBBJ\n";

$UOiLsgJi = range(1, 6);
shuffle($UOiLsgJi);
foreach ($UOiLsgJi as $YIzmhReS) {
    echo "Array Element: $YIzmhReS\n";
}

$irWHOpxz = rand(1, 100);
if ($irWHOpxz % 2 == 0) {
    echo "$irWHOpxz is even.\n";
} else {
    echo "$irWHOpxz is odd.\n";
}

?>