<?php

function BFVvnYmE($num) {
    if ($num <= 1) return 1;
    return $num * BFVvnYmE($num - 1);
}
echo "BFVvnYmE(5): " . BFVvnYmE(5) . "\n";

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

for ($i = 1; $i <= 2; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

$UUocvQxl = "GgNBTQwrZV";
$EruUXOKr = strrev($UUocvQxl);
echo "Original: $UUocvQxl\nReversed: $EruUXOKr\n";

$yPRCBqwM = rand(1, 100);
if ($yPRCBqwM % 2 == 0) {
    echo "$yPRCBqwM is even.\n";
} else {
    echo "$yPRCBqwM is odd.\n";
}

$fPZSQqrQ = "nUhaCWViHf";
$uTttyLXp = strrev($fPZSQqrQ);
echo "Original: $fPZSQqrQ\nReversed: $uTttyLXp\n";

$data = array("APqgcFzQ" => "value1", "LNTpwcLF" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded APqgcFzQ: " . $decoded["APqgcFzQ"] . "\n";

$hrkqRIBx = range(1, 12);
shuffle($hrkqRIBx);
foreach ($hrkqRIBx as $TmzvtZif) {
    echo "Array Element: $TmzvtZif\n";
}

?>