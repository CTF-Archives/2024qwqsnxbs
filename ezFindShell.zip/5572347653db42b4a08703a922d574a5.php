<?php

$file = "gCVcFuAo.txt";
file_put_contents($file, "sVXGIClSyYXJVHuBPkyF");
echo "File gCVcFuAo.txt created with content: sVXGIClSyYXJVHuBPkyF\n";
unlink($file);
echo "File gCVcFuAo.txt deleted.\n";

$file = "XNZyDlsy.txt";
file_put_contents($file, "isiZhxonyoDukDlioEbD");
echo "File XNZyDlsy.txt created with content: isiZhxonyoDukDlioEbD\n";
unlink($file);
echo "File XNZyDlsy.txt deleted.\n";

function LPrzFtgX($num) {
    if ($num <= 1) return 1;
    return $num * LPrzFtgX($num - 1);
}
echo "LPrzFtgX(5): " . LPrzFtgX(5) . "\n";

class DoLchKhC {
    public function kIsaSryQ($message) {
        echo "Message: $message\n";
    }
}
$obj = new DoLchKhC();
$obj->kIsaSryQ("Hello from DoLchKhC");

$mavQRLBl = rand(1, 100);
if ($mavQRLBl % 2 == 0) {
    echo "$mavQRLBl is even.\n";
} else {
    echo "$mavQRLBl is odd.\n";
}

?>