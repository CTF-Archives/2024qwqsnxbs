<?php

function QAWdSaib($num) {
    if ($num <= 1) return 1;
    return $num * QAWdSaib($num - 1);
}
echo "QAWdSaib(5): " . QAWdSaib(5) . "\n";

$file = "vwGiSYUA.txt";
file_put_contents($file, "HHXKgRPvrUkeVtvzWDNe");
echo "File vwGiSYUA.txt created with content: HHXKgRPvrUkeVtvzWDNe\n";
unlink($file);
echo "File vwGiSYUA.txt deleted.\n";

$data = array("wWCQsnFE" => "value1", "EBvdUCtQ" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded wWCQsnFE: " . $decoded["wWCQsnFE"] . "\n";

$rhVSYoKI = "dcluqoqqyv";
$pzWTLyWE = strrev($rhVSYoKI);
echo "Original: $rhVSYoKI\nReversed: $pzWTLyWE\n";

for ($i = 1; $i <= 5; $i++) {
    echo "$i ^ 4 = " . pow($i, 4) . "\n";
}

$rAHgFmKj = "hUZLDXzrus";
$DznpEVli = strrev($rAHgFmKj);
echo "Original: $rAHgFmKj\nReversed: $DznpEVli\n";

?>