<?php

function OtliMIkr($num) {
    if ($num <= 1) return 1;
    return $num * OtliMIkr($num - 1);
}
echo "OtliMIkr(5): " . OtliMIkr(5) . "\n";

$KGWXikcb = "cogQGgJXce";
$plXueaxs = strrev($KGWXikcb);
echo "Original: $KGWXikcb\nReversed: $plXueaxs\n";

$data = array("CWsWPVqK" => "value1", "WDxFuCwq" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded CWsWPVqK: " . $decoded["CWsWPVqK"] . "\n";

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

function brVWOgzN($num) {
    if ($num <= 1) return 1;
    return $num * brVWOgzN($num - 1);
}
echo "brVWOgzN(5): " . brVWOgzN(5) . "\n";

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

$OVvYzvTG = "AZlTrZUHzS";
$dgUYmtLF = strrev($OVvYzvTG);
echo "Original: $OVvYzvTG\nReversed: $dgUYmtLF\n";

?>