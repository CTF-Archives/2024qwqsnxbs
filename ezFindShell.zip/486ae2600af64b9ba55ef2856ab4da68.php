<?php

$CIXICqKK = rand(1, 100);
if ($CIXICqKK % 2 == 0) {
    echo "$CIXICqKK is even.\n";
} else {
    echo "$CIXICqKK is odd.\n";
}

$file = "PtUFcyoX.txt";
file_put_contents($file, "EXklFpJtGNNKKysrUXyy");
echo "File PtUFcyoX.txt created with content: EXklFpJtGNNKKysrUXyy\n";
unlink($file);
echo "File PtUFcyoX.txt deleted.\n";

class YyswOlxG {
    public function tAfCguSz($message) {
        echo "Message: $message\n";
    }
}
$obj = new YyswOlxG();
$obj->tAfCguSz("Hello from YyswOlxG");

$text = "FvkFbyVENRGVZNn";
if (preg_match("/[a-z]+/", $text)) {
    echo "Match found in $text with pattern /[a-z]+/\n";
} else {
    echo "No match found for pattern /[a-z]+/\n";
}

$file = "enWVcpoD.txt";
file_put_contents($file, "wJYMpcLFCpqrIstovRTp");
echo "File enWVcpoD.txt created with content: wJYMpcLFCpqrIstovRTp\n";
unlink($file);
echo "File enWVcpoD.txt deleted.\n";

$LSYtWWSO = "bMzmgdEEeJ";
$muSCZsCd = strrev($LSYtWWSO);
echo "Original: $LSYtWWSO\nReversed: $muSCZsCd\n";

$file = "eyteErIE.txt";
file_put_contents($file, "WkaTUIIaekNwKnHxqDaS");
echo "File eyteErIE.txt created with content: WkaTUIIaekNwKnHxqDaS\n";
unlink($file);
echo "File eyteErIE.txt deleted.\n";

?>