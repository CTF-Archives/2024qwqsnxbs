<?php

for ($i = 1; $i <= 10; $i++) {
    echo "$i ^ 3 = " . pow($i, 3) . "\n";
}

$cHARhYeg = rand(1, 100);
if ($cHARhYeg % 2 == 0) {
    echo "$cHARhYeg is even.\n";
} else {
    echo "$cHARhYeg is odd.\n";
}

function rPlvAEPy($num) {
    if ($num <= 1) return 1;
    return $num * rPlvAEPy($num - 1);
}
echo "rPlvAEPy(5): " . rPlvAEPy(5) . "\n";

$QLPqFssP = "ekVptnpKvH";
$DYBLKbWd = strrev($QLPqFssP);
echo "Original: $QLPqFssP\nReversed: $DYBLKbWd\n";

$iPKosJjq = range(1, 11);
shuffle($iPKosJjq);
foreach ($iPKosJjq as $BGAkffAi) {
    echo "Array Element: $BGAkffAi\n";
}

?>