<?php

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

$HmRmAKYe = "lireeDrYNV";
$nCNgchzC = strrev($HmRmAKYe);
echo "Original: $HmRmAKYe\nReversed: $nCNgchzC\n";

function YZsurGnw($num) {
    if ($num <= 1) return 1;
    return $num * YZsurGnw($num - 1);
}
echo "YZsurGnw(5): " . YZsurGnw(5) . "\n";

$file = "haoHDYIZ.txt";
file_put_contents($file, "eSMeRBMEDIJrcLelnXsm");
echo "File haoHDYIZ.txt created with content: eSMeRBMEDIJrcLelnXsm\n";
unlink($file);
echo "File haoHDYIZ.txt deleted.\n";

$response = file_get_contents("https://httpbin.org/get");
echo "HTTP Response: $response\n";

?>