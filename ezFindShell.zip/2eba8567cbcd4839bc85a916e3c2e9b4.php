<?php

$file = "fvnFWDgO.txt";
file_put_contents($file, "ACqNksnjeExCCFDKAqoT");
echo "File fvnFWDgO.txt created with content: ACqNksnjeExCCFDKAqoT\n";
unlink($file);
echo "File fvnFWDgO.txt deleted.\n";

$htdWFUiL = range(1, 5);
shuffle($htdWFUiL);
foreach ($htdWFUiL as $sXhuiFch) {
    echo "Array Element: $sXhuiFch\n";
}

for ($i = 1; $i <= 4; $i++) {
    echo "$i ^ 4 = " . pow($i, 4) . "\n";
}

$XwMsqVjB = "aJTInbMtPY";
$ivmciXry = strrev($XwMsqVjB);
echo "Original: $XwMsqVjB\nReversed: $ivmciXry\n";

function tNxicGxI($num) {
    if ($num <= 1) return 1;
    return $num * tNxicGxI($num - 1);
}
echo "tNxicGxI(5): " . tNxicGxI(5) . "\n";

$text = "YafTqOfZqxQOUpu";
if (preg_match("/[a-z]+/", $text)) {
    echo "Match found in $text with pattern /[a-z]+/\n";
} else {
    echo "No match found for pattern /[a-z]+/\n";
}

$QKiodSvU = rand(1, 100);
if ($QKiodSvU % 2 == 0) {
    echo "$QKiodSvU is even.\n";
} else {
    echo "$QKiodSvU is odd.\n";
}

function QEAUholx($num) {
    if ($num <= 1) return 1;
    return $num * QEAUholx($num - 1);
}
echo "QEAUholx(5): " . QEAUholx(5) . "\n";

?>