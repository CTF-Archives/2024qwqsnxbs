<?php

$response = file_get_contents("https://httpbin.org/get");
echo "HTTP Response: $response\n";

for ($i = 1; $i <= 5; $i++) {
    echo "$i ^ 3 = " . pow($i, 3) . "\n";
}

$response = file_get_contents("https://httpbin.org/get");
echo "HTTP Response: $response\n";

$text = "OAiTSDQJFJEbZBF";
if (preg_match("/[a-z]+/", $text)) {
    echo "Match found in $text with pattern /[a-z]+/\n";
} else {
    echo "No match found for pattern /[a-z]+/\n";
}

$data = array("NRfUISUe" => "value1", "QWlFkOmK" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded NRfUISUe: " . $decoded["NRfUISUe"] . "\n";

?>