<?php

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

$JKoPZfdF = rand(1, 100);
if ($JKoPZfdF % 2 == 0) {
    echo "$JKoPZfdF is even.\n";
} else {
    echo "$JKoPZfdF is odd.\n";
}

$data = array("MexwpaLO" => "value1", "wxSngvsY" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded MexwpaLO: " . $decoded["MexwpaLO"] . "\n";

for ($i = 1; $i <= 10; $i++) {
    echo "$i ^ 4 = " . pow($i, 4) . "\n";
}

function ijGjlyQx($num) {
    if ($num <= 1) return 1;
    return $num * ijGjlyQx($num - 1);
}
echo "ijGjlyQx(5): " . ijGjlyQx(5) . "\n";

$data = array("eIpoXcaL" => "value1", "dNDBEmmK" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded eIpoXcaL: " . $decoded["eIpoXcaL"] . "\n";

?>