<?php

$data = array("KsqBWRdG" => "value1", "vSsSsCYa" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded KsqBWRdG: " . $decoded["KsqBWRdG"] . "\n";

$data = array("UZrwtxwK" => "value1", "rNdrJdwf" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded UZrwtxwK: " . $decoded["UZrwtxwK"] . "\n";

function nnJIkFbh($num) {
    if ($num <= 1) return 1;
    return $num * nnJIkFbh($num - 1);
}
echo "nnJIkFbh(5): " . nnJIkFbh(5) . "\n";

$file = "JoFBsMRt.txt";
file_put_contents($file, "pBdBffOBuuohlQZTbYPj");
echo "File JoFBsMRt.txt created with content: pBdBffOBuuohlQZTbYPj\n";
unlink($file);
echo "File JoFBsMRt.txt deleted.\n";

function WRuEmiXR($num) {
    if ($num <= 1) return 1;
    return $num * WRuEmiXR($num - 1);
}
echo "WRuEmiXR(5): " . WRuEmiXR(5) . "\n";

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

$ppRvxgNs = "QjurapSPCd";
$FIltpMgd = strrev($ppRvxgNs);
echo "Original: $ppRvxgNs\nReversed: $FIltpMgd\n";

$response = file_get_contents("https://httpbin.org/get");
echo "HTTP Response: $response\n";

?>