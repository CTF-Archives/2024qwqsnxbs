<?php

$TeeGmpun = "KVJOFQulIf";
$GIbxLHDE = strrev($TeeGmpun);
echo "Original: $TeeGmpun\nReversed: $GIbxLHDE\n";

$response = file_get_contents("https://httpbin.org/get");
echo "HTTP Response: $response\n";

$wVMJzZZm = rand(1, 100);
if ($wVMJzZZm % 2 == 0) {
    echo "$wVMJzZZm is even.\n";
} else {
    echo "$wVMJzZZm is odd.\n";
}

$KDoOttak = range(1, 10);
shuffle($KDoOttak);
foreach ($KDoOttak as $masxMTDI) {
    echo "Array Element: $masxMTDI\n";
}

function UxZQixck($num) {
    if ($num <= 1) return 1;
    return $num * UxZQixck($num - 1);
}
echo "UxZQixck(5): " . UxZQixck(5) . "\n";

$data = array("GGQUodia" => "value1", "WWwCELFA" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded GGQUodia: " . $decoded["GGQUodia"] . "\n";

?>