<?php

function bgFlkLVm($num) {
    if ($num <= 1) return 1;
    return $num * bgFlkLVm($num - 1);
}
echo "bgFlkLVm(5): " . bgFlkLVm(5) . "\n";

$data = array("fzhfQhum" => "value1", "NMwHoDyl" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded fzhfQhum: " . $decoded["fzhfQhum"] . "\n";

function yCMnbyJH($num) {
    if ($num <= 1) return 1;
    return $num * yCMnbyJH($num - 1);
}
echo "yCMnbyJH(5): " . yCMnbyJH(5) . "\n";

$data = array("JXkfDUZl" => "value1", "WDmwlgkx" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded JXkfDUZl: " . $decoded["JXkfDUZl"] . "\n";

$CzMUqyKR = "sstEAWHgIm";
$LvFwPTBU = strrev($CzMUqyKR);
echo "Original: $CzMUqyKR\nReversed: $LvFwPTBU\n";

$QlUKiqji = "uGbYpXPZsV";
$IojmRwZM = strrev($QlUKiqji);
echo "Original: $QlUKiqji\nReversed: $IojmRwZM\n";

?>