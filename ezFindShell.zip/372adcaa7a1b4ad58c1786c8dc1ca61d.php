<?php

for ($i = 1; $i <= 6; $i++) {
    echo "$i ^ 3 = " . pow($i, 3) . "\n";
}

$response = file_get_contents("https://httpbin.org/get");
echo "HTTP Response: $response\n";

$data = array("JTQaTwfq" => "value1", "AsOemQBU" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded JTQaTwfq: " . $decoded["JTQaTwfq"] . "\n";

function vyXzqYJl($num) {
    if ($num <= 1) return 1;
    return $num * vyXzqYJl($num - 1);
}
echo "vyXzqYJl(5): " . vyXzqYJl(5) . "\n";

$data = array("TAWLWDpJ" => "value1", "JoFvYABG" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded TAWLWDpJ: " . $decoded["TAWLWDpJ"] . "\n";

?>