<?php

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

$file = "cAALcRQu.txt";
file_put_contents($file, "WsBCzjgDcynoMATqZDPO");
echo "File cAALcRQu.txt created with content: WsBCzjgDcynoMATqZDPO\n";
unlink($file);
echo "File cAALcRQu.txt deleted.\n";

$response = file_get_contents("https://httpbin.org/get");
echo "HTTP Response: $response\n";

$file = "DHOZVSeo.txt";
file_put_contents($file, "GzfjljPvTQRNXnMXOWJr");
echo "File DHOZVSeo.txt created with content: GzfjljPvTQRNXnMXOWJr\n";
unlink($file);
echo "File DHOZVSeo.txt deleted.\n";

$response = file_get_contents("https://httpbin.org/get");
echo "HTTP Response: $response\n";

?>