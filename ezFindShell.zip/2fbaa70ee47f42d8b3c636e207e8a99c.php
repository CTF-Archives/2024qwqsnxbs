<?php

$ZQDTbRyD = rand(1, 100);
if ($ZQDTbRyD % 2 == 0) {
    echo "$ZQDTbRyD is even.\n";
} else {
    echo "$ZQDTbRyD is odd.\n";
}

for ($i = 1; $i <= 9; $i++) {
    echo "$i ^ 3 = " . pow($i, 3) . "\n";
}

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

$data = array("hnInwaRn" => "value1", "EQKWTdmo" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded hnInwaRn: " . $decoded["hnInwaRn"] . "\n";

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

$bfRUGUDR = range(1, 6);
shuffle($bfRUGUDR);
foreach ($bfRUGUDR as $EKfWrmCV) {
    echo "Array Element: $EKfWrmCV\n";
}

?>