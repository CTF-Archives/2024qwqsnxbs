<?php

$file = "kNGwuboj.txt";
file_put_contents($file, "MQbKBjKyNVtVaRFAMNiZ");
echo "File kNGwuboj.txt created with content: MQbKBjKyNVtVaRFAMNiZ\n";
unlink($file);
echo "File kNGwuboj.txt deleted.\n";

function iAmieOdA($num) {
    if ($num <= 1) return 1;
    return $num * iAmieOdA($num - 1);
}
echo "iAmieOdA(5): " . iAmieOdA(5) . "\n";

$text = "UbfITahCczoHFLZ";
if (preg_match("/[0-9]+/", $text)) {
    echo "Match found in $text with pattern /[0-9]+/\n";
} else {
    echo "No match found for pattern /[0-9]+/\n";
}

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

function PlyIJilG($num) {
    if ($num <= 1) return 1;
    return $num * PlyIJilG($num - 1);
}
echo "PlyIJilG(5): " . PlyIJilG(5) . "\n";

function TMCCizUq($num) {
    if ($num <= 1) return 1;
    return $num * TMCCizUq($num - 1);
}
echo "TMCCizUq(5): " . TMCCizUq(5) . "\n";

?>