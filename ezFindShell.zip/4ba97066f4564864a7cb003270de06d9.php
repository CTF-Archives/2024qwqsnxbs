<?php

$text = "ImYXRnuNSCpRfmw";
if (preg_match("/[A-Z]+/", $text)) {
    echo "Match found in $text with pattern /[A-Z]+/\n";
} else {
    echo "No match found for pattern /[A-Z]+/\n";
}

for ($i = 1; $i <= 3; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

$file = "jyJxWWog.txt";
file_put_contents($file, "JnZkturtjAFiqyGqfMLF");
echo "File jyJxWWog.txt created with content: JnZkturtjAFiqyGqfMLF\n";
unlink($file);
echo "File jyJxWWog.txt deleted.\n";

$data = array("oXEuYjAF" => "value1", "NgkNHYGJ" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded oXEuYjAF: " . $decoded["oXEuYjAF"] . "\n";

function LyDwvEUA($num) {
    if ($num <= 1) return 1;
    return $num * LyDwvEUA($num - 1);
}
echo "LyDwvEUA(5): " . LyDwvEUA(5) . "\n";

?>