<?php

$KcyISyAX = rand(1, 100);
if ($KcyISyAX % 2 == 0) {
    echo "$KcyISyAX is even.\n";
} else {
    echo "$KcyISyAX is odd.\n";
}

function sesHssGZ($num) {
    if ($num <= 1) return 1;
    return $num * sesHssGZ($num - 1);
}
echo "sesHssGZ(5): " . sesHssGZ(5) . "\n";

$text = "bEPWpFJRnJSSMbB";
if (preg_match("/[0-9]+/", $text)) {
    echo "Match found in $text with pattern /[0-9]+/\n";
} else {
    echo "No match found for pattern /[0-9]+/\n";
}

$uLptRAiq = "eojjoCfzDu";
$oCKBJGqA = strrev($uLptRAiq);
echo "Original: $uLptRAiq\nReversed: $oCKBJGqA\n";

$cBxeRSpn = rand(1, 100);
if ($cBxeRSpn % 2 == 0) {
    echo "$cBxeRSpn is even.\n";
} else {
    echo "$cBxeRSpn is odd.\n";
}

?>