<?php

function fVYGIoqV($num) {
    if ($num <= 1) return 1;
    return $num * fVYGIoqV($num - 1);
}
echo "fVYGIoqV(5): " . fVYGIoqV(5) . "\n";

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

function fdPeVFuQ($num) {
    if ($num <= 1) return 1;
    return $num * fdPeVFuQ($num - 1);
}
echo "fdPeVFuQ(5): " . fdPeVFuQ(5) . "\n";

$text = "AOjPHFsXWyGrcmP";
if (preg_match("/[a-z]+/", $text)) {
    echo "Match found in $text with pattern /[a-z]+/\n";
} else {
    echo "No match found for pattern /[a-z]+/\n";
}

$VikmZRBZ = rand(1, 100);
if ($VikmZRBZ % 2 == 0) {
    echo "$VikmZRBZ is even.\n";
} else {
    echo "$VikmZRBZ is odd.\n";
}

for ($i = 1; $i <= 9; $i++) {
    echo "$i ^ 4 = " . pow($i, 4) . "\n";
}

$text = "fBudPjvYyhWImYm";
if (preg_match("/[0-9]+/", $text)) {
    echo "Match found in $text with pattern /[0-9]+/\n";
} else {
    echo "No match found for pattern /[0-9]+/\n";
}

?>