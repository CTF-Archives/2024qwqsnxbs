<?php

$dhXzBByo = "GmYFHcWRGU";
$lwYjsWcl = strrev($dhXzBByo);
echo "Original: $dhXzBByo\nReversed: $lwYjsWcl\n";

$csDaZJtc = rand(1, 100);
if ($csDaZJtc % 2 == 0) {
    echo "$csDaZJtc is even.\n";
} else {
    echo "$csDaZJtc is odd.\n";
}

$data = array("cVCokIrP" => "value1", "LVyXxsDJ" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded cVCokIrP: " . $decoded["cVCokIrP"] . "\n";

$text = "LnxdTxeuEuqbaEf";
if (preg_match("/[0-9]+/", $text)) {
    echo "Match found in $text with pattern /[0-9]+/\n";
} else {
    echo "No match found for pattern /[0-9]+/\n";
}

for ($i = 1; $i <= 8; $i++) {
    echo "$i ^ 4 = " . pow($i, 4) . "\n";
}

?>