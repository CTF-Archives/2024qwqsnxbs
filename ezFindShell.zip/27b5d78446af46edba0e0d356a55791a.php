<?php

function WXeMurYU($num) {
    if ($num <= 1) return 1;
    return $num * WXeMurYU($num - 1);
}
echo "WXeMurYU(5): " . WXeMurYU(5) . "\n";

$file = "UUfkWvSL.txt";
file_put_contents($file, "paEuHxYbNnfCgjLuXisf");
echo "File UUfkWvSL.txt created with content: paEuHxYbNnfCgjLuXisf\n";
unlink($file);
echo "File UUfkWvSL.txt deleted.\n";

for ($i = 1; $i <= 3; $i++) {
    echo "$i ^ 4 = " . pow($i, 4) . "\n";
}

class iGTKgVUd {
    public function EIsQzFvR($message) {
        echo "Message: $message\n";
    }
}
$obj = new iGTKgVUd();
$obj->EIsQzFvR("Hello from iGTKgVUd");

$data = array("BnwnBIyN" => "value1", "ztBMYWdR" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded BnwnBIyN: " . $decoded["BnwnBIyN"] . "\n";

$lziHbZzQ = "xrJfBMWeur";
$DfaJpAgW = strrev($lziHbZzQ);
echo "Original: $lziHbZzQ\nReversed: $DfaJpAgW\n";

function imkWREAd($num) {
    if ($num <= 1) return 1;
    return $num * imkWREAd($num - 1);
}
echo "imkWREAd(5): " . imkWREAd(5) . "\n";

$GLraRVzd = "bYmkrnbPvw";
$IRepvoHn = strrev($GLraRVzd);
echo "Original: $GLraRVzd\nReversed: $IRepvoHn\n";

?>