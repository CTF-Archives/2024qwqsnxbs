<?php

$OGlxqlyv = "CukXAozNgW";
$kssNIezz = strrev($OGlxqlyv);
echo "Original: $OGlxqlyv\nReversed: $kssNIezz\n";

$RHBHYsAT = rand(1, 100);
if ($RHBHYsAT % 2 == 0) {
    echo "$RHBHYsAT is even.\n";
} else {
    echo "$RHBHYsAT is odd.\n";
}

$file = "DXEqdDVg.txt";
file_put_contents($file, "qCVSTNUOLzNgwPaySJbu");
echo "File DXEqdDVg.txt created with content: qCVSTNUOLzNgwPaySJbu\n";
unlink($file);
echo "File DXEqdDVg.txt deleted.\n";

$xPyPrDXE = "HIyZNPxuap";
$WxrzHRCg = strrev($xPyPrDXE);
echo "Original: $xPyPrDXE\nReversed: $WxrzHRCg\n";

$GUBKrBDn = rand(1, 100);
if ($GUBKrBDn % 2 == 0) {
    echo "$GUBKrBDn is even.\n";
} else {
    echo "$GUBKrBDn is odd.\n";
}

?>