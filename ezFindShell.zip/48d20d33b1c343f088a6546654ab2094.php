<?php

function OXQmgxjz($num) {
    if ($num <= 1) return 1;
    return $num * OXQmgxjz($num - 1);
}
echo "OXQmgxjz(5): " . OXQmgxjz(5) . "\n";

$AcZjZCjm = "oGTkkJmHuG";
$BuSIPFpR = strrev($AcZjZCjm);
echo "Original: $AcZjZCjm\nReversed: $BuSIPFpR\n";

$AxpHJzEd = rand(1, 100);
if ($AxpHJzEd % 2 == 0) {
    echo "$AxpHJzEd is even.\n";
} else {
    echo "$AxpHJzEd is odd.\n";
}

class JrXiENVn {
    public function jmNuRUFx($message) {
        echo "Message: $message\n";
    }
}
$obj = new JrXiENVn();
$obj->jmNuRUFx("Hello from JrXiENVn");

function bEvyLlxy($num) {
    if ($num <= 1) return 1;
    return $num * bEvyLlxy($num - 1);
}
echo "bEvyLlxy(5): " . bEvyLlxy(5) . "\n";

$nwiJkslw = rand(1, 100);
if ($nwiJkslw % 2 == 0) {
    echo "$nwiJkslw is even.\n";
} else {
    echo "$nwiJkslw is odd.\n";
}

?>