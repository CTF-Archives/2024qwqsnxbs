<?php

$file = "lKgLqWMR.txt";
file_put_contents($file, "FhIKoZyhhqFscwWUHgLD");
echo "File lKgLqWMR.txt created with content: FhIKoZyhhqFscwWUHgLD\n";
unlink($file);
echo "File lKgLqWMR.txt deleted.\n";

$text = "VIQdgAyENPEGjMi";
if (preg_match("/[a-z]+/", $text)) {
    echo "Match found in $text with pattern /[a-z]+/\n";
} else {
    echo "No match found for pattern /[a-z]+/\n";
}

for ($i = 1; $i <= 8; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

$text = "HqTtTtYTwPsThHz";
if (preg_match("/[a-z]+/", $text)) {
    echo "Match found in $text with pattern /[a-z]+/\n";
} else {
    echo "No match found for pattern /[a-z]+/\n";
}

$data = array("uCoDLvpO" => "value1", "SoZRZefd" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded uCoDLvpO: " . $decoded["uCoDLvpO"] . "\n";

$file = "vcHBImRv.txt";
file_put_contents($file, "tuyjKbbAwTjENEsCYKXf");
echo "File vcHBImRv.txt created with content: tuyjKbbAwTjENEsCYKXf\n";
unlink($file);
echo "File vcHBImRv.txt deleted.\n";

?>