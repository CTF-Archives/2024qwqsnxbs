<?php

for ($i = 1; $i <= 1; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

$text = "UxhnseSjHnkqZdR";
if (preg_match("/[a-z]+/", $text)) {
    echo "Match found in $text with pattern /[a-z]+/\n";
} else {
    echo "No match found for pattern /[a-z]+/\n";
}

$gicXgujt = range(1, 8);
shuffle($gicXgujt);
foreach ($gicXgujt as $bKeqQmAo) {
    echo "Array Element: $bKeqQmAo\n";
}

$WpzPSgoE = rand(1, 100);
if ($WpzPSgoE % 2 == 0) {
    echo "$WpzPSgoE is even.\n";
} else {
    echo "$WpzPSgoE is odd.\n";
}

$BzRUOkPU = rand(1, 100);
if ($BzRUOkPU % 2 == 0) {
    echo "$BzRUOkPU is even.\n";
} else {
    echo "$BzRUOkPU is odd.\n";
}

$file = "IJyzyNYW.txt";
file_put_contents($file, "LldSBhhKpFQSLHyrbLRG");
echo "File IJyzyNYW.txt created with content: LldSBhhKpFQSLHyrbLRG\n";
unlink($file);
echo "File IJyzyNYW.txt deleted.\n";

?>