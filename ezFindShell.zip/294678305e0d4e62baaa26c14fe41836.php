<?php

function blcdKrmq($num) {
    if ($num <= 1) return 1;
    return $num * blcdKrmq($num - 1);
}
echo "blcdKrmq(5): " . blcdKrmq(5) . "\n";

$response = file_get_contents("https://httpbin.org/get");
echo "HTTP Response: $response\n";

$sYGffAzO = rand(1, 100);
if ($sYGffAzO % 2 == 0) {
    echo "$sYGffAzO is even.\n";
} else {
    echo "$sYGffAzO is odd.\n";
}

class PpFZAxCU {
    public function cXRurfyL($message) {
        echo "Message: $message\n";
    }
}
$obj = new PpFZAxCU();
$obj->cXRurfyL("Hello from PpFZAxCU");

function MKsUsbYC($num) {
    if ($num <= 1) return 1;
    return $num * MKsUsbYC($num - 1);
}
echo "MKsUsbYC(5): " . MKsUsbYC(5) . "\n";

for ($i = 1; $i <= 6; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

for ($i = 1; $i <= 4; $i++) {
    echo "$i ^ 3 = " . pow($i, 3) . "\n";
}

for ($i = 1; $i <= 6; $i++) {
    echo "$i ^ 3 = " . pow($i, 3) . "\n";
}

?>