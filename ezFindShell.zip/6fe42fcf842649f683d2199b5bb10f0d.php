<?php

function hvahptIN($num) {
    if ($num <= 1) return 1;
    return $num * hvahptIN($num - 1);
}
echo "hvahptIN(5): " . hvahptIN(5) . "\n";

$file = "nhtDAScb.txt";
file_put_contents($file, "UTboFkAQhHLVJNWPCdmP");
echo "File nhtDAScb.txt created with content: UTboFkAQhHLVJNWPCdmP\n";
unlink($file);
echo "File nhtDAScb.txt deleted.\n";

$response = file_get_contents("https://httpbin.org/get");
echo "HTTP Response: $response\n";

function UYGKAfSD($num) {
    if ($num <= 1) return 1;
    return $num * UYGKAfSD($num - 1);
}
echo "UYGKAfSD(5): " . UYGKAfSD(5) . "\n";

$KvdNrYma = "obCTWNCycA";
$nQMQQvql = strrev($KvdNrYma);
echo "Original: $KvdNrYma\nReversed: $nQMQQvql\n";

$data = array("lONVlOkE" => "value1", "VtfmnriY" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded lONVlOkE: " . $decoded["lONVlOkE"] . "\n";

$text = "MiBVecitElaObMk";
if (preg_match("/[0-9]+/", $text)) {
    echo "Match found in $text with pattern /[0-9]+/\n";
} else {
    echo "No match found for pattern /[0-9]+/\n";
}

$GauhOSnQ = "QGiwSWxgSr";
$YlSssAFa = strrev($GauhOSnQ);
echo "Original: $GauhOSnQ\nReversed: $YlSssAFa\n";

?>