<?php

$file = "Qnnuqsqf.txt";
file_put_contents($file, "KpitmoJaSGYwYkixyMEU");
echo "File Qnnuqsqf.txt created with content: KpitmoJaSGYwYkixyMEU\n";
unlink($file);
echo "File Qnnuqsqf.txt deleted.\n";

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

$file = "RoumppDg.txt";
file_put_contents($file, "UqaEhNGhkIekhYvNOqcF");
echo "File RoumppDg.txt created with content: UqaEhNGhkIekhYvNOqcF\n";
unlink($file);
echo "File RoumppDg.txt deleted.\n";

for ($i = 1; $i <= 4; $i++) {
    echo "$i ^ 4 = " . pow($i, 4) . "\n";
}

$text = "AZxHoXxnHmYmVur";
if (preg_match("/[A-Z]+/", $text)) {
    echo "Match found in $text with pattern /[A-Z]+/\n";
} else {
    echo "No match found for pattern /[A-Z]+/\n";
}

?>