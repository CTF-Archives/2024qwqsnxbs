<?php

$file = "ivlIcMXt.txt";
file_put_contents($file, "nmmVObJAlXZeuPzKBdWQ");
echo "File ivlIcMXt.txt created with content: nmmVObJAlXZeuPzKBdWQ\n";
unlink($file);
echo "File ivlIcMXt.txt deleted.\n";

$file = "abpuBCKc.txt";
file_put_contents($file, "yQfTGoKylkZKISYUPfNM");
echo "File abpuBCKc.txt created with content: yQfTGoKylkZKISYUPfNM\n";
unlink($file);
echo "File abpuBCKc.txt deleted.\n";

function DLZkNvOk($num) {
    if ($num <= 1) return 1;
    return $num * DLZkNvOk($num - 1);
}
echo "DLZkNvOk(5): " . DLZkNvOk(5) . "\n";

class IsQmBQjY {
    public function cMRjGjmh($message) {
        echo "Message: $message\n";
    }
}
$obj = new IsQmBQjY();
$obj->cMRjGjmh("Hello from IsQmBQjY");

$data = array("ZGjlQMXt" => "value1", "zKiZRnMP" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded ZGjlQMXt: " . $decoded["ZGjlQMXt"] . "\n";

?>