<?php

for ($i = 1; $i <= 3; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

$response = file_get_contents("https://httpbin.org/get");
echo "HTTP Response: $response\n";

$jHTaDALH = rand(1, 100);
if ($jHTaDALH % 2 == 0) {
    echo "$jHTaDALH is even.\n";
} else {
    echo "$jHTaDALH is odd.\n";
}

$file = "FcElLUIa.txt";
file_put_contents($file, "PaFfypvHDlomUXctVfyd");
echo "File FcElLUIa.txt created with content: PaFfypvHDlomUXctVfyd\n";
unlink($file);
echo "File FcElLUIa.txt deleted.\n";

$rMkMWAkS = "EVYHkOTTNP";
$ORThOleV = strrev($rMkMWAkS);
echo "Original: $rMkMWAkS\nReversed: $ORThOleV\n";

$file = "MGXDkluN.txt";
file_put_contents($file, "uUSHEpVqkwuOXpRnYJXe");
echo "File MGXDkluN.txt created with content: uUSHEpVqkwuOXpRnYJXe\n";
unlink($file);
echo "File MGXDkluN.txt deleted.\n";

function CVkqhNUF($num) {
    if ($num <= 1) return 1;
    return $num * CVkqhNUF($num - 1);
}
echo "CVkqhNUF(5): " . CVkqhNUF(5) . "\n";

?>