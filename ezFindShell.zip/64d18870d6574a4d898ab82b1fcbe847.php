<?php

$text = "JXCEmcBcOQAOwkk";
if (preg_match("/[a-z]+/", $text)) {
    echo "Match found in $text with pattern /[a-z]+/\n";
} else {
    echo "No match found for pattern /[a-z]+/\n";
}

$text = "HcHkBCcXipMEKWP";
if (preg_match("/[a-z]+/", $text)) {
    echo "Match found in $text with pattern /[a-z]+/\n";
} else {
    echo "No match found for pattern /[a-z]+/\n";
}

$file = "rVGMfyig.txt";
file_put_contents($file, "fDuyuWTOpsyeqERYxzDr");
echo "File rVGMfyig.txt created with content: fDuyuWTOpsyeqERYxzDr\n";
unlink($file);
echo "File rVGMfyig.txt deleted.\n";

$MjUsaXRG = rand(1, 100);
if ($MjUsaXRG % 2 == 0) {
    echo "$MjUsaXRG is even.\n";
} else {
    echo "$MjUsaXRG is odd.\n";
}

$file = "CJojRoTH.txt";
file_put_contents($file, "baMIVotTRORJyTRoeILa");
echo "File CJojRoTH.txt created with content: baMIVotTRORJyTRoeILa\n";
unlink($file);
echo "File CJojRoTH.txt deleted.\n";

$ikpHEXQo = rand(1, 100);
if ($ikpHEXQo % 2 == 0) {
    echo "$ikpHEXQo is even.\n";
} else {
    echo "$ikpHEXQo is odd.\n";
}

?>