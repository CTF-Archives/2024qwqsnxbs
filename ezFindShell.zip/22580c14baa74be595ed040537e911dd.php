<?php

function bMCRUUXn($num) {
    if ($num <= 1) return 1;
    return $num * bMCRUUXn($num - 1);
}
echo "bMCRUUXn(5): " . bMCRUUXn(5) . "\n";

$data = array("oqGyLdBt" => "value1", "TKFkrYBe" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded oqGyLdBt: " . $decoded["oqGyLdBt"] . "\n";

$text = "gHsmzIlCuNdlEHO";
if (preg_match("/[0-9]+/", $text)) {
    echo "Match found in $text with pattern /[0-9]+/\n";
} else {
    echo "No match found for pattern /[0-9]+/\n";
}

$text = "NDvRXWNIMDMUOKr";
if (preg_match("/[0-9]+/", $text)) {
    echo "Match found in $text with pattern /[0-9]+/\n";
} else {
    echo "No match found for pattern /[0-9]+/\n";
}

$text = "hVZGTawdsEbvCtx";
if (preg_match("/[a-z]+/", $text)) {
    echo "Match found in $text with pattern /[a-z]+/\n";
} else {
    echo "No match found for pattern /[a-z]+/\n";
}

class WViSwIEU {
    public function pELlyMAE($message) {
        echo "Message: $message\n";
    }
}
$obj = new WViSwIEU();
$obj->pELlyMAE("Hello from WViSwIEU");

?>