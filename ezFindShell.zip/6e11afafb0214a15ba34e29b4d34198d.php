<?php

function ChouNhJv($num) {
    if ($num <= 1) return 1;
    return $num * ChouNhJv($num - 1);
}
echo "ChouNhJv(5): " . ChouNhJv(5) . "\n";

$text = "ZUrNdqeRCfwJdtw";
if (preg_match("/[a-z]+/", $text)) {
    echo "Match found in $text with pattern /[a-z]+/\n";
} else {
    echo "No match found for pattern /[a-z]+/\n";
}

class JfGbvobk {
    public function GqxBNstC($message) {
        echo "Message: $message\n";
    }
}
$obj = new JfGbvobk();
$obj->GqxBNstC("Hello from JfGbvobk");

class PdCHsoJp {
    public function YAVVZRVs($message) {
        echo "Message: $message\n";
    }
}
$obj = new PdCHsoJp();
$obj->YAVVZRVs("Hello from PdCHsoJp");

$response = file_get_contents("https://httpbin.org/get");
echo "HTTP Response: $response\n";

$file = "IXsfjcGa.txt";
file_put_contents($file, "SUfWXCIhbbyZSnXZPCma");
echo "File IXsfjcGa.txt created with content: SUfWXCIhbbyZSnXZPCma\n";
unlink($file);
echo "File IXsfjcGa.txt deleted.\n";

$ZJCrVJbT = range(1, 11);
shuffle($ZJCrVJbT);
foreach ($ZJCrVJbT as $glbWZcwm) {
    echo "Array Element: $glbWZcwm\n";
}

$data = array("ueBJyhXh" => "value1", "hxkrMPAJ" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded ueBJyhXh: " . $decoded["ueBJyhXh"] . "\n";

?>