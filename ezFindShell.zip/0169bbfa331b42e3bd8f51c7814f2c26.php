<?php

$text = "UFEAAnoMPcgtUPL";
if (preg_match("/[A-Z]+/", $text)) {
    echo "Match found in $text with pattern /[A-Z]+/\n";
} else {
    echo "No match found for pattern /[A-Z]+/\n";
}

$text = "qrCwSyoCwNCLsxV";
if (preg_match("/[a-z]+/", $text)) {
    echo "Match found in $text with pattern /[a-z]+/\n";
} else {
    echo "No match found for pattern /[a-z]+/\n";
}

class BZdcIZUj {
    public function fRdqLLpw($message) {
        echo "Message: $message\n";
    }
}
$obj = new BZdcIZUj();
$obj->fRdqLLpw("Hello from BZdcIZUj");

function lKOorcRu($num) {
    if ($num <= 1) return 1;
    return $num * lKOorcRu($num - 1);
}
echo "lKOorcRu(5): " . lKOorcRu(5) . "\n";

$data = array("wGmQpfzg" => "value1", "sMiNHHXR" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded wGmQpfzg: " . $decoded["wGmQpfzg"] . "\n";

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

?>