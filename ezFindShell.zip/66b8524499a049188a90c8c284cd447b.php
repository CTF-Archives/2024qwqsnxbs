<?php

function fKnmksYC($num) {
    if ($num <= 1) return 1;
    return $num * fKnmksYC($num - 1);
}
echo "fKnmksYC(5): " . fKnmksYC(5) . "\n";

class hQdZTwbs {
    public function aBqPTLks($message) {
        echo "Message: $message\n";
    }
}
$obj = new hQdZTwbs();
$obj->aBqPTLks("Hello from hQdZTwbs");

for ($i = 1; $i <= 7; $i++) {
    echo "$i ^ 4 = " . pow($i, 4) . "\n";
}

for ($i = 1; $i <= 6; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

$text = "FHNStlwmatUqtxt";
if (preg_match("/[a-z]+/", $text)) {
    echo "Match found in $text with pattern /[a-z]+/\n";
} else {
    echo "No match found for pattern /[a-z]+/\n";
}

$HhByRpzV = range(1, 7);
shuffle($HhByRpzV);
foreach ($HhByRpzV as $brYvfocf) {
    echo "Array Element: $brYvfocf\n";
}

$response = file_get_contents("https://httpbin.org/get");
echo "HTTP Response: $response\n";

$EHzamAhK = rand(1, 100);
if ($EHzamAhK % 2 == 0) {
    echo "$EHzamAhK is even.\n";
} else {
    echo "$EHzamAhK is odd.\n";
}

?>