<?php

$lVhDiYhK = rand(1, 100);
if ($lVhDiYhK % 2 == 0) {
    echo "$lVhDiYhK is even.\n";
} else {
    echo "$lVhDiYhK is odd.\n";
}

$data = array("cWCQdPsD" => "value1", "sIcQBxiA" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded cWCQdPsD: " . $decoded["cWCQdPsD"] . "\n";

function SmkBiVUR($num) {
    if ($num <= 1) return 1;
    return $num * SmkBiVUR($num - 1);
}
echo "SmkBiVUR(5): " . SmkBiVUR(5) . "\n";

$GghPkwGE = "fMDRgsMccL";
$dikLLxdv = strrev($GghPkwGE);
echo "Original: $GghPkwGE\nReversed: $dikLLxdv\n";

for ($i = 1; $i <= 9; $i++) {
    echo "$i ^ 4 = " . pow($i, 4) . "\n";
}

?>