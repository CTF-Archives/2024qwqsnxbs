<?php

$JrSiwMpT = rand(1, 100);
if ($JrSiwMpT % 2 == 0) {
    echo "$JrSiwMpT is even.\n";
} else {
    echo "$JrSiwMpT is odd.\n";
}

$text = "KIgOGOaegWUccZF";
if (preg_match("/[0-9]+/", $text)) {
    echo "Match found in $text with pattern /[0-9]+/\n";
} else {
    echo "No match found for pattern /[0-9]+/\n";
}

$file = "jNLtCFyc.txt";
file_put_contents($file, "sxUOSrgWZLWdwRwKnstL");
echo "File jNLtCFyc.txt created with content: sxUOSrgWZLWdwRwKnstL\n";
unlink($file);
echo "File jNLtCFyc.txt deleted.\n";

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

$text = "MsxzAPTZbqMlMED";
if (preg_match("/[0-9]+/", $text)) {
    echo "Match found in $text with pattern /[0-9]+/\n";
} else {
    echo "No match found for pattern /[0-9]+/\n";
}

$RsYIgwBA = rand(1, 100);
if ($RsYIgwBA % 2 == 0) {
    echo "$RsYIgwBA is even.\n";
} else {
    echo "$RsYIgwBA is odd.\n";
}

$data = array("iWKNQXqr" => "value1", "NoQCmkdz" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded iWKNQXqr: " . $decoded["iWKNQXqr"] . "\n";

$GSVgaQsQ = rand(1, 100);
if ($GSVgaQsQ % 2 == 0) {
    echo "$GSVgaQsQ is even.\n";
} else {
    echo "$GSVgaQsQ is odd.\n";
}

?>