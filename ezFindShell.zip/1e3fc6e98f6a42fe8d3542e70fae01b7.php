<?php

$response = file_get_contents("https://httpbin.org/get");
echo "HTTP Response: $response\n";

$HUGssvxt = rand(1, 100);
if ($HUGssvxt % 2 == 0) {
    echo "$HUGssvxt is even.\n";
} else {
    echo "$HUGssvxt is odd.\n";
}

function bkpAGiJb($num) {
    if ($num <= 1) return 1;
    return $num * bkpAGiJb($num - 1);
}
echo "bkpAGiJb(5): " . bkpAGiJb(5) . "\n";

$LhDmeYAN = "wNTyLoGFws";
$MbnqJXcJ = strrev($LhDmeYAN);
echo "Original: $LhDmeYAN\nReversed: $MbnqJXcJ\n";

for ($i = 1; $i <= 10; $i++) {
    echo "$i ^ 4 = " . pow($i, 4) . "\n";
}

for ($i = 1; $i <= 6; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

$text = "MzoQkEaSOaTjAFF";
if (preg_match("/[0-9]+/", $text)) {
    echo "Match found in $text with pattern /[0-9]+/\n";
} else {
    echo "No match found for pattern /[0-9]+/\n";
}

?>