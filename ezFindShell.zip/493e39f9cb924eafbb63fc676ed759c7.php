<?php

$nYiMwSki = rand(1, 100);
if ($nYiMwSki % 2 == 0) {
    echo "$nYiMwSki is even.\n";
} else {
    echo "$nYiMwSki is odd.\n";
}

$RIdHPSTU = range(1, 7);
shuffle($RIdHPSTU);
foreach ($RIdHPSTU as $oywWDdCv) {
    echo "Array Element: $oywWDdCv\n";
}

$uNYQLhbi = "cRASmPBtyB";
$AgddtVGC = strrev($uNYQLhbi);
echo "Original: $uNYQLhbi\nReversed: $AgddtVGC\n";

for ($i = 1; $i <= 4; $i++) {
    echo "$i ^ 4 = " . pow($i, 4) . "\n";
}

function ekPgPymD($num) {
    if ($num <= 1) return 1;
    return $num * ekPgPymD($num - 1);
}
echo "ekPgPymD(5): " . ekPgPymD(5) . "\n";

?>