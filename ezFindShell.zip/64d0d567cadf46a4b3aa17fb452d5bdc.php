<?php

$kvDZIFYr = rand(1, 100);
if ($kvDZIFYr % 2 == 0) {
    echo "$kvDZIFYr is even.\n";
} else {
    echo "$kvDZIFYr is odd.\n";
}

$lfCUWWSb = rand(1, 100);
if ($lfCUWWSb % 2 == 0) {
    echo "$lfCUWWSb is even.\n";
} else {
    echo "$lfCUWWSb is odd.\n";
}

$data = array("gnWhtVea" => "value1", "BcneZbzO" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded gnWhtVea: " . $decoded["gnWhtVea"] . "\n";

$WNqOTaxS = range(1, 10);
shuffle($WNqOTaxS);
foreach ($WNqOTaxS as $GblrXcgl) {
    echo "Array Element: $GblrXcgl\n";
}

$VHoSwjUA = rand(1, 100);
if ($VHoSwjUA % 2 == 0) {
    echo "$VHoSwjUA is even.\n";
} else {
    echo "$VHoSwjUA is odd.\n";
}

$AaqVawHv = "ylAUgXmLAT";
$tvkrYhke = strrev($AaqVawHv);
echo "Original: $AaqVawHv\nReversed: $tvkrYhke\n";

for ($i = 1; $i <= 5; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

?>