<?php

for ($i = 1; $i <= 4; $i++) {
    echo "$i ^ 4 = " . pow($i, 4) . "\n";
}

$data = array("FnGTElef" => "value1", "AJJeuJvi" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded FnGTElef: " . $decoded["FnGTElef"] . "\n";

$data = array("vVVYrdmp" => "value1", "lYJBMeAI" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded vVVYrdmp: " . $decoded["vVVYrdmp"] . "\n";

for ($i = 1; $i <= 7; $i++) {
    echo "$i ^ 3 = " . pow($i, 3) . "\n";
}

$lnrnYWFp = "eKHZNWWjNM";
$bJHPTEMT = strrev($lnrnYWFp);
echo "Original: $lnrnYWFp\nReversed: $bJHPTEMT\n";

?>