<?php

$file = "xJhOqfIy.txt";
file_put_contents($file, "DgHhJpJAnmgrPfcrbCRJ");
echo "File xJhOqfIy.txt created with content: DgHhJpJAnmgrPfcrbCRJ\n";
unlink($file);
echo "File xJhOqfIy.txt deleted.\n";

$file = "pzBdMLij.txt";
file_put_contents($file, "VWwxTWvmDkyqiYSJnEhc");
echo "File pzBdMLij.txt created with content: VWwxTWvmDkyqiYSJnEhc\n";
unlink($file);
echo "File pzBdMLij.txt deleted.\n";

$file = "vErSrInN.txt";
file_put_contents($file, "UkRLYLtDhDrgaxUDzJYc");
echo "File vErSrInN.txt created with content: UkRLYLtDhDrgaxUDzJYc\n";
unlink($file);
echo "File vErSrInN.txt deleted.\n";

$text = "ECJwjeTpQJXVjUW";
if (preg_match("/[0-9]+/", $text)) {
    echo "Match found in $text with pattern /[0-9]+/\n";
} else {
    echo "No match found for pattern /[0-9]+/\n";
}

$text = "zPSULCczxHSDTnV";
if (preg_match("/[a-z]+/", $text)) {
    echo "Match found in $text with pattern /[a-z]+/\n";
} else {
    echo "No match found for pattern /[a-z]+/\n";
}

$text = "zwjKbvSdwXClTlh";
if (preg_match("/[A-Z]+/", $text)) {
    echo "Match found in $text with pattern /[A-Z]+/\n";
} else {
    echo "No match found for pattern /[A-Z]+/\n";
}

$uwtqZtsg = range(1, 14);
shuffle($uwtqZtsg);
foreach ($uwtqZtsg as $HXAFKisK) {
    echo "Array Element: $HXAFKisK\n";
}

?>