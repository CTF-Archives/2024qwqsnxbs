<?php

$text = "zbvCZHwCjfRcVFG";
if (preg_match("/[a-z]+/", $text)) {
    echo "Match found in $text with pattern /[a-z]+/\n";
} else {
    echo "No match found for pattern /[a-z]+/\n";
}

function LPhWbaGi($num) {
    if ($num <= 1) return 1;
    return $num * LPhWbaGi($num - 1);
}
echo "LPhWbaGi(5): " . LPhWbaGi(5) . "\n";

$data = array("RnVEVUdA" => "value1", "JiQQTnpq" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded RnVEVUdA: " . $decoded["RnVEVUdA"] . "\n";

class QXPmrzON {
    public function JJhZnBoK($message) {
        echo "Message: $message\n";
    }
}
$obj = new QXPmrzON();
$obj->JJhZnBoK("Hello from QXPmrzON");

$HRHaRijE = rand(1, 100);
if ($HRHaRijE % 2 == 0) {
    echo "$HRHaRijE is even.\n";
} else {
    echo "$HRHaRijE is odd.\n";
}

?>