<?php

$data = array("gMbxvKcN" => "value1", "nxzUWowx" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded gMbxvKcN: " . $decoded["gMbxvKcN"] . "\n";

$ATyLTQyL = rand(1, 100);
if ($ATyLTQyL % 2 == 0) {
    echo "$ATyLTQyL is even.\n";
} else {
    echo "$ATyLTQyL is odd.\n";
}

class ZhbfezBM {
    public function BtQxxGaK($message) {
        echo "Message: $message\n";
    }
}
$obj = new ZhbfezBM();
$obj->BtQxxGaK("Hello from ZhbfezBM");

function JsgEcEiE($num) {
    if ($num <= 1) return 1;
    return $num * JsgEcEiE($num - 1);
}
echo "JsgEcEiE(5): " . JsgEcEiE(5) . "\n";

$lLMkVXbk = "vpSsTLakis";
$zZgqpFJF = strrev($lLMkVXbk);
echo "Original: $lLMkVXbk\nReversed: $zZgqpFJF\n";

class HpVdShcw {
    public function WADphvRw($message) {
        echo "Message: $message\n";
    }
}
$obj = new HpVdShcw();
$obj->WADphvRw("Hello from HpVdShcw");

$text = "MYFaLhOGufMutDH";
if (preg_match("/[A-Z]+/", $text)) {
    echo "Match found in $text with pattern /[A-Z]+/\n";
} else {
    echo "No match found for pattern /[A-Z]+/\n";
}

$text = "rOycIvTMRANvrHe";
if (preg_match("/[0-9]+/", $text)) {
    echo "Match found in $text with pattern /[0-9]+/\n";
} else {
    echo "No match found for pattern /[0-9]+/\n";
}

?>