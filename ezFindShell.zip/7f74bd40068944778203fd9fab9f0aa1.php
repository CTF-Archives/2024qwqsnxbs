<?php

$data = array("sqTRAiQg" => "value1", "GDzoYGuk" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded sqTRAiQg: " . $decoded["sqTRAiQg"] . "\n";

function uTXHXFkT($num) {
    if ($num <= 1) return 1;
    return $num * uTXHXFkT($num - 1);
}
echo "uTXHXFkT(5): " . uTXHXFkT(5) . "\n";

function LKJZBgyh($num) {
    if ($num <= 1) return 1;
    return $num * LKJZBgyh($num - 1);
}
echo "LKJZBgyh(5): " . LKJZBgyh(5) . "\n";

class eSFCJdIT {
    public function Iyapjwxw($message) {
        echo "Message: $message\n";
    }
}
$obj = new eSFCJdIT();
$obj->Iyapjwxw("Hello from eSFCJdIT");

for ($i = 1; $i <= 9; $i++) {
    echo "$i ^ 3 = " . pow($i, 3) . "\n";
}

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

?>