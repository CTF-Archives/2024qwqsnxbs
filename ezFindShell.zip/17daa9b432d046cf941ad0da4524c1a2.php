<?php

function fMDviROq($num) {
    if ($num <= 1) return 1;
    return $num * fMDviROq($num - 1);
}
echo "fMDviROq(5): " . fMDviROq(5) . "\n";

$data = array("EzMFySlS" => "value1", "sfAeAnPK" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded EzMFySlS: " . $decoded["EzMFySlS"] . "\n";

$cbnVnIpC = rand(1, 100);
if ($cbnVnIpC % 2 == 0) {
    echo "$cbnVnIpC is even.\n";
} else {
    echo "$cbnVnIpC is odd.\n";
}

function JzjOiGna($num) {
    if ($num <= 1) return 1;
    return $num * JzjOiGna($num - 1);
}
echo "JzjOiGna(5): " . JzjOiGna(5) . "\n";

for ($i = 1; $i <= 9; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

$hzGhyXUk = range(1, 9);
shuffle($hzGhyXUk);
foreach ($hzGhyXUk as $DilEzmAV) {
    echo "Array Element: $DilEzmAV\n";
}

$LesdjneR = "lboaCPtnhT";
$OpMlytwR = strrev($LesdjneR);
echo "Original: $LesdjneR\nReversed: $OpMlytwR\n";

?>