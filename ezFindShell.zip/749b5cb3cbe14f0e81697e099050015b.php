<?php

for ($i = 1; $i <= 1; $i++) {
    echo "$i ^ 4 = " . pow($i, 4) . "\n";
}

function BDupCBMH($num) {
    if ($num <= 1) return 1;
    return $num * BDupCBMH($num - 1);
}
echo "BDupCBMH(5): " . BDupCBMH(5) . "\n";

$rNPKkBUV = "lyhskBMnIa";
$bGhTSTPQ = strrev($rNPKkBUV);
echo "Original: $rNPKkBUV\nReversed: $bGhTSTPQ\n";

function TDkkpzIT($num) {
    if ($num <= 1) return 1;
    return $num * TDkkpzIT($num - 1);
}
echo "TDkkpzIT(5): " . TDkkpzIT(5) . "\n";

class flsCGnka {
    public function xXUZnWHy($message) {
        echo "Message: $message\n";
    }
}
$obj = new flsCGnka();
$obj->xXUZnWHy("Hello from flsCGnka");

function HzpCAllh($num) {
    if ($num <= 1) return 1;
    return $num * HzpCAllh($num - 1);
}
echo "HzpCAllh(5): " . HzpCAllh(5) . "\n";

?>