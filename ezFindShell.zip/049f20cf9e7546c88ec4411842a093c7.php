<?php

for ($i = 1; $i <= 9; $i++) {
    echo "$i ^ 3 = " . pow($i, 3) . "\n";
}

$file = "SYEUCoTr.txt";
file_put_contents($file, "nTugHeWejoYsWIfXVcIC");
echo "File SYEUCoTr.txt created with content: nTugHeWejoYsWIfXVcIC\n";
unlink($file);
echo "File SYEUCoTr.txt deleted.\n";

$bHsjeXis = rand(1, 100);
if ($bHsjeXis % 2 == 0) {
    echo "$bHsjeXis is even.\n";
} else {
    echo "$bHsjeXis is odd.\n";
}

function ZJEgDzeY($num) {
    if ($num <= 1) return 1;
    return $num * ZJEgDzeY($num - 1);
}
echo "ZJEgDzeY(5): " . ZJEgDzeY(5) . "\n";

$AzDJpQFy = rand(1, 100);
if ($AzDJpQFy % 2 == 0) {
    echo "$AzDJpQFy is even.\n";
} else {
    echo "$AzDJpQFy is odd.\n";
}

?>