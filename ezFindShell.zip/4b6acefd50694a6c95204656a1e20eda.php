<?php

function aPlxkwkf($num) {
    if ($num <= 1) return 1;
    return $num * aPlxkwkf($num - 1);
}
echo "aPlxkwkf(5): " . aPlxkwkf(5) . "\n";

$eXsSTCHW = "UtwWYvgIJP";
$EZfXTxtN = strrev($eXsSTCHW);
echo "Original: $eXsSTCHW\nReversed: $EZfXTxtN\n";

$text = "qOHNkIleWRbMMAV";
if (preg_match("/[a-z]+/", $text)) {
    echo "Match found in $text with pattern /[a-z]+/\n";
} else {
    echo "No match found for pattern /[a-z]+/\n";
}

$MenQFMcl = range(1, 11);
shuffle($MenQFMcl);
foreach ($MenQFMcl as $UFSWTCcJ) {
    echo "Array Element: $UFSWTCcJ\n";
}

for ($i = 1; $i <= 6; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

?>