<?php

$text = "UpxkVTUDWchXTrz";
if (preg_match("/[A-Z]+/", $text)) {
    echo "Match found in $text with pattern /[A-Z]+/\n";
} else {
    echo "No match found for pattern /[A-Z]+/\n";
}

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

$response = file_get_contents("https://httpbin.org/get");
echo "HTTP Response: $response\n";

function XpbgvglE($num) {
    if ($num <= 1) return 1;
    return $num * XpbgvglE($num - 1);
}
echo "XpbgvglE(5): " . XpbgvglE(5) . "\n";

for ($i = 1; $i <= 5; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

$text = "jlCOfuGIFjnGRnl";
if (preg_match("/[0-9]+/", $text)) {
    echo "Match found in $text with pattern /[0-9]+/\n";
} else {
    echo "No match found for pattern /[0-9]+/\n";
}

function iGAlFIEo($num) {
    if ($num <= 1) return 1;
    return $num * iGAlFIEo($num - 1);
}
echo "iGAlFIEo(5): " . iGAlFIEo(5) . "\n";

?>