<?php

$CyupeziM = rand(1, 100);
if ($CyupeziM % 2 == 0) {
    echo "$CyupeziM is even.\n";
} else {
    echo "$CyupeziM is odd.\n";
}

class cPjEVVOO {
    public function BLNEGIWJ($message) {
        echo "Message: $message\n";
    }
}
$obj = new cPjEVVOO();
$obj->BLNEGIWJ("Hello from cPjEVVOO");

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

class eoUPWsJA {
    public function VyeEnJHj($message) {
        echo "Message: $message\n";
    }
}
$obj = new eoUPWsJA();
$obj->VyeEnJHj("Hello from eoUPWsJA");

for ($i = 1; $i <= 9; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

function jNpoNEaV($num) {
    if ($num <= 1) return 1;
    return $num * jNpoNEaV($num - 1);
}
echo "jNpoNEaV(5): " . jNpoNEaV(5) . "\n";

function tjhKgfkv($num) {
    if ($num <= 1) return 1;
    return $num * tjhKgfkv($num - 1);
}
echo "tjhKgfkv(5): " . tjhKgfkv(5) . "\n";

function cBxSNyHE($num) {
    if ($num <= 1) return 1;
    return $num * cBxSNyHE($num - 1);
}
echo "cBxSNyHE(5): " . cBxSNyHE(5) . "\n";

?>