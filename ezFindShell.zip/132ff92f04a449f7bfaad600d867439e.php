<?php

function NifmLcmM($num) {
    if ($num <= 1) return 1;
    return $num * NifmLcmM($num - 1);
}
echo "NifmLcmM(5): " . NifmLcmM(5) . "\n";

class ZMVfjmrv {
    public function eoJqzkfo($message) {
        echo "Message: $message\n";
    }
}
$obj = new ZMVfjmrv();
$obj->eoJqzkfo("Hello from ZMVfjmrv");

for ($i = 1; $i <= 1; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

$WraKlSfq = "taEMiWcilt";
$YwEMOQbY = strrev($WraKlSfq);
echo "Original: $WraKlSfq\nReversed: $YwEMOQbY\n";

$GMRqeBhD = "nomcMfJiVx";
$gDCFUhvo = strrev($GMRqeBhD);
echo "Original: $GMRqeBhD\nReversed: $gDCFUhvo\n";

?>