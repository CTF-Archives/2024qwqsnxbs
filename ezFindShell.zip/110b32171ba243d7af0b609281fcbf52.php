<?php

$data = array("rAdSJQrY" => "value1", "dvatlLgu" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded rAdSJQrY: " . $decoded["rAdSJQrY"] . "\n";

function NOzEgLMp($num) {
    if ($num <= 1) return 1;
    return $num * NOzEgLMp($num - 1);
}
echo "NOzEgLMp(5): " . NOzEgLMp(5) . "\n";

$nRXVXqrk = range(1, 10);
shuffle($nRXVXqrk);
foreach ($nRXVXqrk as $pSXvkNER) {
    echo "Array Element: $pSXvkNER\n";
}

$IGQAGsvM = rand(1, 100);
if ($IGQAGsvM % 2 == 0) {
    echo "$IGQAGsvM is even.\n";
} else {
    echo "$IGQAGsvM is odd.\n";
}

$file = "WbphnWwz.txt";
file_put_contents($file, "jCRjZTmUwyAtWKaWqXgX");
echo "File WbphnWwz.txt created with content: jCRjZTmUwyAtWKaWqXgX\n";
unlink($file);
echo "File WbphnWwz.txt deleted.\n";

$kLsJlMvO = rand(1, 100);
if ($kLsJlMvO % 2 == 0) {
    echo "$kLsJlMvO is even.\n";
} else {
    echo "$kLsJlMvO is odd.\n";
}

$RppJuRGH = range(1, 6);
shuffle($RppJuRGH);
foreach ($RppJuRGH as $YFtzxcYZ) {
    echo "Array Element: $YFtzxcYZ\n";
}

?>