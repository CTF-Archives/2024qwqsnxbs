<?php

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

for ($i = 1; $i <= 10; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

class fjCRBROJ {
    public function LgpWoCBR($message) {
        echo "Message: $message\n";
    }
}
$obj = new fjCRBROJ();
$obj->LgpWoCBR("Hello from fjCRBROJ");

?>