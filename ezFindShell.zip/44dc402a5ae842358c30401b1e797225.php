<?php

function thGIAFMK($num) {
    if ($num <= 1) return 1;
    return $num * thGIAFMK($num - 1);
}
echo "thGIAFMK(5): " . thGIAFMK(5) . "\n";

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

function RXXcZbcn($num) {
    if ($num <= 1) return 1;
    return $num * RXXcZbcn($num - 1);
}
echo "RXXcZbcn(5): " . RXXcZbcn(5) . "\n";

$file = "mjrHUfSu.txt";
file_put_contents($file, "RhOJQUwbtGXqUjzKgqQF");
echo "File mjrHUfSu.txt created with content: RhOJQUwbtGXqUjzKgqQF\n";
unlink($file);
echo "File mjrHUfSu.txt deleted.\n";

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

for ($i = 1; $i <= 8; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

$vNgkYzSW = "EbGTFmBHFj";
$RsUDBdlP = strrev($vNgkYzSW);
echo "Original: $vNgkYzSW\nReversed: $RsUDBdlP\n";

$ogSvCAti = range(1, 13);
shuffle($ogSvCAti);
foreach ($ogSvCAti as $mAdfJEKk) {
    echo "Array Element: $mAdfJEKk\n";
}

?>