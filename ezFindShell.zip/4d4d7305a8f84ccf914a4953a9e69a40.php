<?php

for ($i = 1; $i <= 5; $i++) {
    echo "$i ^ 4 = " . pow($i, 4) . "\n";
}

$KXjYxmKs = "fXwGBXerji";
$MQAVMmtb = strrev($KXjYxmKs);
echo "Original: $KXjYxmKs\nReversed: $MQAVMmtb\n";

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

function aXzJDECZ($num) {
    if ($num <= 1) return 1;
    return $num * aXzJDECZ($num - 1);
}
echo "aXzJDECZ(5): " . aXzJDECZ(5) . "\n";

$text = "TKOsYhWEhanlGvA";
if (preg_match("/[a-z]+/", $text)) {
    echo "Match found in $text with pattern /[a-z]+/\n";
} else {
    echo "No match found for pattern /[a-z]+/\n";
}

?>