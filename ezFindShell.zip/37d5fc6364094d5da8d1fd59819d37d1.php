<?php

$text = "vTReztRXoUGfGWR";
if (preg_match("/[a-z]+/", $text)) {
    echo "Match found in $text with pattern /[a-z]+/\n";
} else {
    echo "No match found for pattern /[a-z]+/\n";
}

for ($i = 1; $i <= 7; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

$GfKbAXBb = "MwVrdypBBo";
$nZLXRtNA = strrev($GfKbAXBb);
echo "Original: $GfKbAXBb\nReversed: $nZLXRtNA\n";

$file = "NXvmgnex.txt";
file_put_contents($file, "BXCRjMmtTPpwwZUpnEJV");
echo "File NXvmgnex.txt created with content: BXCRjMmtTPpwwZUpnEJV\n";
unlink($file);
echo "File NXvmgnex.txt deleted.\n";

$text = "NBHzdRUrDDUIaxz";
if (preg_match("/[a-z]+/", $text)) {
    echo "Match found in $text with pattern /[a-z]+/\n";
} else {
    echo "No match found for pattern /[a-z]+/\n";
}

?>