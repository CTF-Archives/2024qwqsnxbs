<?php

$vaVfNaHW = rand(1, 100);
if ($vaVfNaHW % 2 == 0) {
    echo "$vaVfNaHW is even.\n";
} else {
    echo "$vaVfNaHW is odd.\n";
}

$DJMyEaci = rand(1, 100);
if ($DJMyEaci % 2 == 0) {
    echo "$DJMyEaci is even.\n";
} else {
    echo "$DJMyEaci is odd.\n";
}

$ifsvokar = range(1, 12);
shuffle($ifsvokar);
foreach ($ifsvokar as $tAzHUQtl) {
    echo "Array Element: $tAzHUQtl\n";
}

for ($i = 1; $i <= 3; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

$data = array("KypzVAXH" => "value1", "DyFQrmxC" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded KypzVAXH: " . $decoded["KypzVAXH"] . "\n";

?>