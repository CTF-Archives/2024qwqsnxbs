<?php

$text = "rGTYPPTEPQczfrB";
if (preg_match("/[A-Z]+/", $text)) {
    echo "Match found in $text with pattern /[A-Z]+/\n";
} else {
    echo "No match found for pattern /[A-Z]+/\n";
}

$file = "yghEgpdZ.txt";
file_put_contents($file, "IqFzqKzlMVlavTGcvBKS");
echo "File yghEgpdZ.txt created with content: IqFzqKzlMVlavTGcvBKS\n";
unlink($file);
echo "File yghEgpdZ.txt deleted.\n";

$mvKXItdX = rand(1, 100);
if ($mvKXItdX % 2 == 0) {
    echo "$mvKXItdX is even.\n";
} else {
    echo "$mvKXItdX is odd.\n";
}

$RLUGQShV = "ajWRZsZZTt";
$VNmoGfFx = strrev($RLUGQShV);
echo "Original: $RLUGQShV\nReversed: $VNmoGfFx\n";

$text = "WaQmFIuNqPUqTCp";
if (preg_match("/[A-Z]+/", $text)) {
    echo "Match found in $text with pattern /[A-Z]+/\n";
} else {
    echo "No match found for pattern /[A-Z]+/\n";
}

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

for ($i = 1; $i <= 3; $i++) {
    echo "$i ^ 4 = " . pow($i, 4) . "\n";
}

?>