<?php

for ($i = 1; $i <= 5; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

class VlRZsbXr {
    public function iNREKJuk($message) {
        echo "Message: $message\n";
    }
}
$obj = new VlRZsbXr();
$obj->iNREKJuk("Hello from VlRZsbXr");

for ($i = 1; $i <= 8; $i++) {
    echo "$i ^ 3 = " . pow($i, 3) . "\n";
}

$text = "kMIBmpWyIDAfSbJ";
if (preg_match("/[a-z]+/", $text)) {
    echo "Match found in $text with pattern /[a-z]+/\n";
} else {
    echo "No match found for pattern /[a-z]+/\n";
}

$file = "uJFltMuo.txt";
file_put_contents($file, "JuewzclfsHfdkEoWqgrJ");
echo "File uJFltMuo.txt created with content: JuewzclfsHfdkEoWqgrJ\n";
unlink($file);
echo "File uJFltMuo.txt deleted.\n";

?>