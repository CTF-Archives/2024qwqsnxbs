<?php

$file = "wnMTldir.txt";
file_put_contents($file, "TVYYPecpNJkVSWUuqqMO");
echo "File wnMTldir.txt created with content: TVYYPecpNJkVSWUuqqMO\n";
unlink($file);
echo "File wnMTldir.txt deleted.\n";

function JrqBhOqR($num) {
    if ($num <= 1) return 1;
    return $num * JrqBhOqR($num - 1);
}
echo "JrqBhOqR(5): " . JrqBhOqR(5) . "\n";

$file = "fKAewHob.txt";
file_put_contents($file, "uaLcpLnIhRytHiCPEqbH");
echo "File fKAewHob.txt created with content: uaLcpLnIhRytHiCPEqbH\n";
unlink($file);
echo "File fKAewHob.txt deleted.\n";

$file = "nIiPCYYu.txt";
file_put_contents($file, "HGeUtLqqWNUzvgCMZuWI");
echo "File nIiPCYYu.txt created with content: HGeUtLqqWNUzvgCMZuWI\n";
unlink($file);
echo "File nIiPCYYu.txt deleted.\n";

$response = file_get_contents("https://httpbin.org/get");
echo "HTTP Response: $response\n";

$file = "bxShwMuR.txt";
file_put_contents($file, "SjysMSyLXPIoQsGaEIlU");
echo "File bxShwMuR.txt created with content: SjysMSyLXPIoQsGaEIlU\n";
unlink($file);
echo "File bxShwMuR.txt deleted.\n";

?>