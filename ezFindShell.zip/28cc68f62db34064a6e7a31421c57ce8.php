<?php

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

function ZabxnGPS($num) {
    if ($num <= 1) return 1;
    return $num * ZabxnGPS($num - 1);
}
echo "ZabxnGPS(5): " . ZabxnGPS(5) . "\n";

$jPTNLkZa = range(1, 6);
shuffle($jPTNLkZa);
foreach ($jPTNLkZa as $LYnJoCfA) {
    echo "Array Element: $LYnJoCfA\n";
}

function guoumliX($num) {
    if ($num <= 1) return 1;
    return $num * guoumliX($num - 1);
}
echo "guoumliX(5): " . guoumliX(5) . "\n";

$response = file_get_contents("https://httpbin.org/get");
echo "HTTP Response: $response\n";

$HcxAVXbg = "cpsPwnLBkI";
$CrYTJjqb = strrev($HcxAVXbg);
echo "Original: $HcxAVXbg\nReversed: $CrYTJjqb\n";

$data = array("GmPFIwci" => "value1", "yyGmZFvF" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded GmPFIwci: " . $decoded["GmPFIwci"] . "\n";

for ($i = 1; $i <= 10; $i++) {
    echo "$i ^ 4 = " . pow($i, 4) . "\n";
}

?>