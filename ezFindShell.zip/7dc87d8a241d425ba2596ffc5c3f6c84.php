<?php

$YSOopDZw = rand(1, 100);
if ($YSOopDZw % 2 == 0) {
    echo "$YSOopDZw is even.\n";
} else {
    echo "$YSOopDZw is odd.\n";
}

function piGHbOLl($num) {
    if ($num <= 1) return 1;
    return $num * piGHbOLl($num - 1);
}
echo "piGHbOLl(5): " . piGHbOLl(5) . "\n";

$QiOCQGyJ = range(1, 10);
shuffle($QiOCQGyJ);
foreach ($QiOCQGyJ as $vaTVmIHn) {
    echo "Array Element: $vaTVmIHn\n";
}

$JiYnEgCY = range(1, 13);
shuffle($JiYnEgCY);
foreach ($JiYnEgCY as $kgxBMFsN) {
    echo "Array Element: $kgxBMFsN\n";
}

$text = "xrEqBOhmippjPyB";
if (preg_match("/[A-Z]+/", $text)) {
    echo "Match found in $text with pattern /[A-Z]+/\n";
} else {
    echo "No match found for pattern /[A-Z]+/\n";
}

$uWAUHCAP = "HMKKpdyjTR";
$dkUnjXfx = strrev($uWAUHCAP);
echo "Original: $uWAUHCAP\nReversed: $dkUnjXfx\n";

?>