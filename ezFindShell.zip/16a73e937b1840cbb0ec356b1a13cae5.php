<?php

$response = file_get_contents("https://httpbin.org/get");
echo "HTTP Response: $response\n";

function tSDtnxEL($num) {
    if ($num <= 1) return 1;
    return $num * tSDtnxEL($num - 1);
}
echo "tSDtnxEL(5): " . tSDtnxEL(5) . "\n";

$sTiIHrCG = rand(1, 100);
if ($sTiIHrCG % 2 == 0) {
    echo "$sTiIHrCG is even.\n";
} else {
    echo "$sTiIHrCG is odd.\n";
}

for ($i = 1; $i <= 4; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

function ZNarKMnZ($num) {
    if ($num <= 1) return 1;
    return $num * ZNarKMnZ($num - 1);
}
echo "ZNarKMnZ(5): " . ZNarKMnZ(5) . "\n";

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

?>