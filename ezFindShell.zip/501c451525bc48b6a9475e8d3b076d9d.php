<?php

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

$zQUQsfaS = "UxiOJCOqXS";
$vpiIFcrX = strrev($zQUQsfaS);
echo "Original: $zQUQsfaS\nReversed: $vpiIFcrX\n";

$tIXVLRak = rand(1, 100);
if ($tIXVLRak % 2 == 0) {
    echo "$tIXVLRak is even.\n";
} else {
    echo "$tIXVLRak is odd.\n";
}

function xcBgQYFV($num) {
    if ($num <= 1) return 1;
    return $num * xcBgQYFV($num - 1);
}
echo "xcBgQYFV(5): " . xcBgQYFV(5) . "\n";

$text = "COtrReHilcGwnBz";
if (preg_match("/[0-9]+/", $text)) {
    echo "Match found in $text with pattern /[0-9]+/\n";
} else {
    echo "No match found for pattern /[0-9]+/\n";
}

$file = "TuksfnWF.txt";
file_put_contents($file, "WAuAeMgQUQYBCJnvtWYu");
echo "File TuksfnWF.txt created with content: WAuAeMgQUQYBCJnvtWYu\n";
unlink($file);
echo "File TuksfnWF.txt deleted.\n";

$text = "PZzzVtHdGhQsZGr";
if (preg_match("/[a-z]+/", $text)) {
    echo "Match found in $text with pattern /[a-z]+/\n";
} else {
    echo "No match found for pattern /[a-z]+/\n";
}

?>