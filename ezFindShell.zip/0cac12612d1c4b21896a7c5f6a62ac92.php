<?php

for ($i = 1; $i <= 9; $i++) {
    echo "$i ^ 4 = " . pow($i, 4) . "\n";
}

for ($i = 1; $i <= 8; $i++) {
    echo "$i ^ 3 = " . pow($i, 3) . "\n";
}

for ($i = 1; $i <= 10; $i++) {
    echo "$i ^ 3 = " . pow($i, 3) . "\n";
}

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

$file = "pIDrQSJu.txt";
file_put_contents($file, "dpzTmRCwWkZxqVrkDZnp");
echo "File pIDrQSJu.txt created with content: dpzTmRCwWkZxqVrkDZnp\n";
unlink($file);
echo "File pIDrQSJu.txt deleted.\n";

$gthchMlw = range(1, 5);
shuffle($gthchMlw);
foreach ($gthchMlw as $PwJSRYBE) {
    echo "Array Element: $PwJSRYBE\n";
}

?>