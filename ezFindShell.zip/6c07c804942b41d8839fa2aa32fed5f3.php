<?php

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

$data = array("vDaOrWWT" => "value1", "SGpzkgts" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded vDaOrWWT: " . $decoded["vDaOrWWT"] . "\n";

$vfnuwfxa = "rgaywNMNxy";
$XgIMzadI = strrev($vfnuwfxa);
echo "Original: $vfnuwfxa\nReversed: $XgIMzadI\n";

$nFCVngNn = "aZOIXVZWTr";
$XvrOAWOz = strrev($nFCVngNn);
echo "Original: $nFCVngNn\nReversed: $XvrOAWOz\n";

$file = "MCmYkmFn.txt";
file_put_contents($file, "sDLloZNARdYIptjPFGyd");
echo "File MCmYkmFn.txt created with content: sDLloZNARdYIptjPFGyd\n";
unlink($file);
echo "File MCmYkmFn.txt deleted.\n";

?>