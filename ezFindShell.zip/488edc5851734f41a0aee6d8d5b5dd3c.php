<?php

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

$file = "ukQizrmn.txt";
file_put_contents($file, "vrwoWYNEcgbudDpHNKhP");
echo "File ukQizrmn.txt created with content: vrwoWYNEcgbudDpHNKhP\n";
unlink($file);
echo "File ukQizrmn.txt deleted.\n";

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

$rMxzOvCk = range(1, 11);
shuffle($rMxzOvCk);
foreach ($rMxzOvCk as $qLJslTmE) {
    echo "Array Element: $qLJslTmE\n";
}

$HNTgftbU = range(1, 7);
shuffle($HNTgftbU);
foreach ($HNTgftbU as $ToTdJUVC) {
    echo "Array Element: $ToTdJUVC\n";
}

?>