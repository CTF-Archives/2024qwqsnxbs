<?php

function ivRSqpck($num) {
    if ($num <= 1) return 1;
    return $num * ivRSqpck($num - 1);
}
echo "ivRSqpck(5): " . ivRSqpck(5) . "\n";

function RewPUYcI($num) {
    if ($num <= 1) return 1;
    return $num * RewPUYcI($num - 1);
}
echo "RewPUYcI(5): " . RewPUYcI(5) . "\n";

$GeycwPqS = rand(1, 100);
if ($GeycwPqS % 2 == 0) {
    echo "$GeycwPqS is even.\n";
} else {
    echo "$GeycwPqS is odd.\n";
}

$kdOszVSW = "cfgrkXcsQv";
$jEgodlGe = strrev($kdOszVSW);
echo "Original: $kdOszVSW\nReversed: $jEgodlGe\n";

function CuMpGhtj($num) {
    if ($num <= 1) return 1;
    return $num * CuMpGhtj($num - 1);
}
echo "CuMpGhtj(5): " . CuMpGhtj(5) . "\n";

$data = array("wkNIXBnQ" => "value1", "FEEddZKD" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded wkNIXBnQ: " . $decoded["wkNIXBnQ"] . "\n";

$text = "swHumDxplDUKvTP";
if (preg_match("/[0-9]+/", $text)) {
    echo "Match found in $text with pattern /[0-9]+/\n";
} else {
    echo "No match found for pattern /[0-9]+/\n";
}

?>