<?php

$data = array("WgVLxkkm" => "value1", "YDVoykzb" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded WgVLxkkm: " . $decoded["WgVLxkkm"] . "\n";

$data = array("JzfmAwYi" => "value1", "csUpKXUo" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded JzfmAwYi: " . $decoded["JzfmAwYi"] . "\n";

$file = "BLhPJxKO.txt";
file_put_contents($file, "oBKFdWrUOGdsgItsSCPO");
echo "File BLhPJxKO.txt created with content: oBKFdWrUOGdsgItsSCPO\n";
unlink($file);
echo "File BLhPJxKO.txt deleted.\n";

function AxWKNSBb($num) {
    if ($num <= 1) return 1;
    return $num * AxWKNSBb($num - 1);
}
echo "AxWKNSBb(5): " . AxWKNSBb(5) . "\n";

$response = file_get_contents("https://httpbin.org/get");
echo "HTTP Response: $response\n";

$lnvRHGgm = rand(1, 100);
if ($lnvRHGgm % 2 == 0) {
    echo "$lnvRHGgm is even.\n";
} else {
    echo "$lnvRHGgm is odd.\n";
}

function ekNASryD($num) {
    if ($num <= 1) return 1;
    return $num * ekNASryD($num - 1);
}
echo "ekNASryD(5): " . ekNASryD(5) . "\n";

for ($i = 1; $i <= 5; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

?>