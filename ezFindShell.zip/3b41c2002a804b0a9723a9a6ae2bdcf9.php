<?php

for ($i = 1; $i <= 2; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

$LOAMakbx = range(1, 6);
shuffle($LOAMakbx);
foreach ($LOAMakbx as $JkcGobfK) {
    echo "Array Element: $JkcGobfK\n";
}

$RObOeosZ = rand(1, 100);
if ($RObOeosZ % 2 == 0) {
    echo "$RObOeosZ is even.\n";
} else {
    echo "$RObOeosZ is odd.\n";
}

$data = array("MxaiIBHQ" => "value1", "jopqeysp" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded MxaiIBHQ: " . $decoded["MxaiIBHQ"] . "\n";

$data = array("igFebYQU" => "value1", "EkGbFzyb" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded igFebYQU: " . $decoded["igFebYQU"] . "\n";

$NmljAOEz = "fXpSJlWIZn";
$SqJIlvqr = strrev($NmljAOEz);
echo "Original: $NmljAOEz\nReversed: $SqJIlvqr\n";

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

?>