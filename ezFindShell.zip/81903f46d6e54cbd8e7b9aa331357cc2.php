<?php

$text = "VNwyyxiFpEBxHag";
if (preg_match("/[0-9]+/", $text)) {
    echo "Match found in $text with pattern /[0-9]+/\n";
} else {
    echo "No match found for pattern /[0-9]+/\n";
}

for ($i = 1; $i <= 2; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

for ($i = 1; $i <= 3; $i++) {
    echo "$i ^ 3 = " . pow($i, 3) . "\n";
}

$text = "HCaHDyRqYsxVBGr";
if (preg_match("/[0-9]+/", $text)) {
    echo "Match found in $text with pattern /[0-9]+/\n";
} else {
    echo "No match found for pattern /[0-9]+/\n";
}

function GLidksgi($num) {
    if ($num <= 1) return 1;
    return $num * GLidksgi($num - 1);
}
echo "GLidksgi(5): " . GLidksgi(5) . "\n";

$response = file_get_contents("https://httpbin.org/get");
echo "HTTP Response: $response\n";

?>