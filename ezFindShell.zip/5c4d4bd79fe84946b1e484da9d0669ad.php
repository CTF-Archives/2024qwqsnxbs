<?php

$file = "XtxNPDGZ.txt";
file_put_contents($file, "wiQojodoavOtymUkowDn");
echo "File XtxNPDGZ.txt created with content: wiQojodoavOtymUkowDn\n";
unlink($file);
echo "File XtxNPDGZ.txt deleted.\n";

$oErgsVjK = rand(1, 100);
if ($oErgsVjK % 2 == 0) {
    echo "$oErgsVjK is even.\n";
} else {
    echo "$oErgsVjK is odd.\n";
}

function BPsKtzFB($num) {
    if ($num <= 1) return 1;
    return $num * BPsKtzFB($num - 1);
}
echo "BPsKtzFB(5): " . BPsKtzFB(5) . "\n";

$response = file_get_contents("https://httpbin.org/get");
echo "HTTP Response: $response\n";

for ($i = 1; $i <= 9; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

$ApkefTSI = "cUnYQYwUUR";
$wNlRhIyd = strrev($ApkefTSI);
echo "Original: $ApkefTSI\nReversed: $wNlRhIyd\n";

?>