<?php

for ($i = 1; $i <= 7; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

for ($i = 1; $i <= 1; $i++) {
    echo "$i ^ 4 = " . pow($i, 4) . "\n";
}

for ($i = 1; $i <= 4; $i++) {
    echo "$i ^ 4 = " . pow($i, 4) . "\n";
}

$file = "JNwVlOii.txt";
file_put_contents($file, "WCMCKrNjzJuhHysqDGWV");
echo "File JNwVlOii.txt created with content: WCMCKrNjzJuhHysqDGWV\n";
unlink($file);
echo "File JNwVlOii.txt deleted.\n";

$kzMujeAq = range(1, 13);
shuffle($kzMujeAq);
foreach ($kzMujeAq as $hzpVfUtW) {
    echo "Array Element: $hzpVfUtW\n";
}

$response = file_get_contents("https://httpbin.org/get");
echo "HTTP Response: $response\n";

$text = "YoBnZldifFEhYmE";
if (preg_match("/[0-9]+/", $text)) {
    echo "Match found in $text with pattern /[0-9]+/\n";
} else {
    echo "No match found for pattern /[0-9]+/\n";
}

?>