<?php

$text = "lRosxcknVryhzTm";
if (preg_match("/[0-9]+/", $text)) {
    echo "Match found in $text with pattern /[0-9]+/\n";
} else {
    echo "No match found for pattern /[0-9]+/\n";
}

$text = "aSXYdwpzmEgJZTe";
if (preg_match("/[0-9]+/", $text)) {
    echo "Match found in $text with pattern /[0-9]+/\n";
} else {
    echo "No match found for pattern /[0-9]+/\n";
}

$klPduvMJ = range(1, 15);
shuffle($klPduvMJ);
foreach ($klPduvMJ as $iIkAscxI) {
    echo "Array Element: $iIkAscxI\n";
}

for ($i = 1; $i <= 4; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

$ZdBLeaPz = range(1, 11);
shuffle($ZdBLeaPz);
foreach ($ZdBLeaPz as $QfBlQLPm) {
    echo "Array Element: $QfBlQLPm\n";
}

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

for ($i = 1; $i <= 9; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

?>