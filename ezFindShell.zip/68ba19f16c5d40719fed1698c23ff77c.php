<?php

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

for ($i = 1; $i <= 5; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

$qkIlTwBZ = rand(1, 100);
if ($qkIlTwBZ % 2 == 0) {
    echo "$qkIlTwBZ is even.\n";
} else {
    echo "$qkIlTwBZ is odd.\n";
}

$data = array("NHREGkdo" => "value1", "qMuONIMb" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded NHREGkdo: " . $decoded["NHREGkdo"] . "\n";

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

?>