<?php

for ($i = 1; $i <= 10; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

function JrcOaYOE($num) {
    if ($num <= 1) return 1;
    return $num * JrcOaYOE($num - 1);
}
echo "JrcOaYOE(5): " . JrcOaYOE(5) . "\n";

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

function qQUGqvKY($num) {
    if ($num <= 1) return 1;
    return $num * qQUGqvKY($num - 1);
}
echo "qQUGqvKY(5): " . qQUGqvKY(5) . "\n";

for ($i = 1; $i <= 1; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

$file = "xikBBNII.txt";
file_put_contents($file, "fuITQFSYFhdvHPfSHMNY");
echo "File xikBBNII.txt created with content: fuITQFSYFhdvHPfSHMNY\n";
unlink($file);
echo "File xikBBNII.txt deleted.\n";

$OHUdvPgA = rand(1, 100);
if ($OHUdvPgA % 2 == 0) {
    echo "$OHUdvPgA is even.\n";
} else {
    echo "$OHUdvPgA is odd.\n";
}

?>