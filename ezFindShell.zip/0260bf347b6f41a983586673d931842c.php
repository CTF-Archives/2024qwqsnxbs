<?php

$text = "bwSBvqeNmOxZRkd";
if (preg_match("/[A-Z]+/", $text)) {
    echo "Match found in $text with pattern /[A-Z]+/\n";
} else {
    echo "No match found for pattern /[A-Z]+/\n";
}

for ($i = 1; $i <= 5; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

$text = "cUqYJUXZFeqRsdX";
if (preg_match("/[a-z]+/", $text)) {
    echo "Match found in $text with pattern /[a-z]+/\n";
} else {
    echo "No match found for pattern /[a-z]+/\n";
}

$yiraEYxa = rand(1, 100);
if ($yiraEYxa % 2 == 0) {
    echo "$yiraEYxa is even.\n";
} else {
    echo "$yiraEYxa is odd.\n";
}

$OiuqKqTd = "FjfqzTVIeM";
$KXsWSFGW = strrev($OiuqKqTd);
echo "Original: $OiuqKqTd\nReversed: $KXsWSFGW\n";

?>