<?php

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

$SiKzAZyO = "yULSRScokv";
$IbSjLwDS = strrev($SiKzAZyO);
echo "Original: $SiKzAZyO\nReversed: $IbSjLwDS\n";

$file = "tuFxjnpk.txt";
file_put_contents($file, "EVtyxEsoWwsqvxDGzrku");
echo "File tuFxjnpk.txt created with content: EVtyxEsoWwsqvxDGzrku\n";
unlink($file);
echo "File tuFxjnpk.txt deleted.\n";

function rsYzKFHP($num) {
    if ($num <= 1) return 1;
    return $num * rsYzKFHP($num - 1);
}
echo "rsYzKFHP(5): " . rsYzKFHP(5) . "\n";

$ypCTTnLn = range(1, 15);
shuffle($ypCTTnLn);
foreach ($ypCTTnLn as $PzDfXIvj) {
    echo "Array Element: $PzDfXIvj\n";
}

$DokkCrzC = rand(1, 100);
if ($DokkCrzC % 2 == 0) {
    echo "$DokkCrzC is even.\n";
} else {
    echo "$DokkCrzC is odd.\n";
}

?>