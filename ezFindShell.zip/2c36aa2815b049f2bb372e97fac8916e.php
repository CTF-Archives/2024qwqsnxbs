<?php

function QzIpoVFF($num) {
    if ($num <= 1) return 1;
    return $num * QzIpoVFF($num - 1);
}
echo "QzIpoVFF(5): " . QzIpoVFF(5) . "\n";

$liwdogdD = rand(1, 100);
if ($liwdogdD % 2 == 0) {
    echo "$liwdogdD is even.\n";
} else {
    echo "$liwdogdD is odd.\n";
}

$DXcTLyIT = rand(1, 100);
if ($DXcTLyIT % 2 == 0) {
    echo "$DXcTLyIT is even.\n";
} else {
    echo "$DXcTLyIT is odd.\n";
}

$xnELsYmN = "VkPACpSuEV";
$JMezFLcN = strrev($xnELsYmN);
echo "Original: $xnELsYmN\nReversed: $JMezFLcN\n";

$file = "EGkhbmpg.txt";
file_put_contents($file, "ZWKAPsNBNgZpdGtDhxnU");
echo "File EGkhbmpg.txt created with content: ZWKAPsNBNgZpdGtDhxnU\n";
unlink($file);
echo "File EGkhbmpg.txt deleted.\n";

?>