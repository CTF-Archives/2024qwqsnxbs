<?php

$text = "WJTomJSxsxmrTze";
if (preg_match("/[a-z]+/", $text)) {
    echo "Match found in $text with pattern /[a-z]+/\n";
} else {
    echo "No match found for pattern /[a-z]+/\n";
}

$ZOeWNWHR = range(1, 11);
shuffle($ZOeWNWHR);
foreach ($ZOeWNWHR as $eTdjzjdC) {
    echo "Array Element: $eTdjzjdC\n";
}

$text = "ycqVyCFFJNjSsSp";
if (preg_match("/[A-Z]+/", $text)) {
    echo "Match found in $text with pattern /[A-Z]+/\n";
} else {
    echo "No match found for pattern /[A-Z]+/\n";
}

function ANItCERa($num) {
    if ($num <= 1) return 1;
    return $num * ANItCERa($num - 1);
}
echo "ANItCERa(5): " . ANItCERa(5) . "\n";

for ($i = 1; $i <= 4; $i++) {
    echo "$i ^ 3 = " . pow($i, 3) . "\n";
}

?>