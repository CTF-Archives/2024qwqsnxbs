<?php

$text = "kGPbFHvNhfbDxKW";
if (preg_match("/[0-9]+/", $text)) {
    echo "Match found in $text with pattern /[0-9]+/\n";
} else {
    echo "No match found for pattern /[0-9]+/\n";
}

$text = "kRilqCrwaQrMpxf";
if (preg_match("/[a-z]+/", $text)) {
    echo "Match found in $text with pattern /[a-z]+/\n";
} else {
    echo "No match found for pattern /[a-z]+/\n";
}

$file = "tPxpEwnf.txt";
file_put_contents($file, "FefbSHkUcQByTWwxZMAT");
echo "File tPxpEwnf.txt created with content: FefbSHkUcQByTWwxZMAT\n";
unlink($file);
echo "File tPxpEwnf.txt deleted.\n";

for ($i = 1; $i <= 8; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

function uoUbCLmF($num) {
    if ($num <= 1) return 1;
    return $num * uoUbCLmF($num - 1);
}
echo "uoUbCLmF(5): " . uoUbCLmF(5) . "\n";

?>