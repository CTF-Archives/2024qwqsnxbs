<?php

$qTPGDXzt = rand(1, 100);
if ($qTPGDXzt % 2 == 0) {
    echo "$qTPGDXzt is even.\n";
} else {
    echo "$qTPGDXzt is odd.\n";
}

$PlUMtpSd = rand(1, 100);
if ($PlUMtpSd % 2 == 0) {
    echo "$PlUMtpSd is even.\n";
} else {
    echo "$PlUMtpSd is odd.\n";
}

$neRycVtf = range(1, 6);
shuffle($neRycVtf);
foreach ($neRycVtf as $BKcTyUqF) {
    echo "Array Element: $BKcTyUqF\n";
}

function esXALBkl($num) {
    if ($num <= 1) return 1;
    return $num * esXALBkl($num - 1);
}
echo "esXALBkl(5): " . esXALBkl(5) . "\n";

$aGSsFmhs = range(1, 13);
shuffle($aGSsFmhs);
foreach ($aGSsFmhs as $xnLlDkUQ) {
    echo "Array Element: $xnLlDkUQ\n";
}

function KDyHSAop($num) {
    if ($num <= 1) return 1;
    return $num * KDyHSAop($num - 1);
}
echo "KDyHSAop(5): " . KDyHSAop(5) . "\n";

?>