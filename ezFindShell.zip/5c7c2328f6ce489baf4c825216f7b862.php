<?php

function iVgLDswf($num) {
    if ($num <= 1) return 1;
    return $num * iVgLDswf($num - 1);
}
echo "iVgLDswf(5): " . iVgLDswf(5) . "\n";

$BJsEykLO = range(1, 12);
shuffle($BJsEykLO);
foreach ($BJsEykLO as $tIyNXzDH) {
    echo "Array Element: $tIyNXzDH\n";
}

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

$file = "kcFBKLpL.txt";
file_put_contents($file, "vetzhkameyszDhaSAgNX");
echo "File kcFBKLpL.txt created with content: vetzhkameyszDhaSAgNX\n";
unlink($file);
echo "File kcFBKLpL.txt deleted.\n";

function PCkXYyoc($num) {
    if ($num <= 1) return 1;
    return $num * PCkXYyoc($num - 1);
}
echo "PCkXYyoc(5): " . PCkXYyoc(5) . "\n";

$dsXAfwwQ = rand(1, 100);
if ($dsXAfwwQ % 2 == 0) {
    echo "$dsXAfwwQ is even.\n";
} else {
    echo "$dsXAfwwQ is odd.\n";
}

?>