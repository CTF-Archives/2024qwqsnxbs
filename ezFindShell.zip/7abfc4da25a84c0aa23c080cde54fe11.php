<?php

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

for ($i = 1; $i <= 4; $i++) {
    echo "$i ^ 3 = " . pow($i, 3) . "\n";
}

$OCAJQJCF = rand(1, 100);
if ($OCAJQJCF % 2 == 0) {
    echo "$OCAJQJCF is even.\n";
} else {
    echo "$OCAJQJCF is odd.\n";
}

function oELuSjGi($num) {
    if ($num <= 1) return 1;
    return $num * oELuSjGi($num - 1);
}
echo "oELuSjGi(5): " . oELuSjGi(5) . "\n";

$aIMJBGVY = rand(1, 100);
if ($aIMJBGVY % 2 == 0) {
    echo "$aIMJBGVY is even.\n";
} else {
    echo "$aIMJBGVY is odd.\n";
}

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

?>