<?php

$file = "ctibTpCZ.txt";
file_put_contents($file, "AQUQlzvPDekCLNfWmcEk");
echo "File ctibTpCZ.txt created with content: AQUQlzvPDekCLNfWmcEk\n";
unlink($file);
echo "File ctibTpCZ.txt deleted.\n";

function hMjKPLDP($num) {
    if ($num <= 1) return 1;
    return $num * hMjKPLDP($num - 1);
}
echo "hMjKPLDP(5): " . hMjKPLDP(5) . "\n";

$HTzZtjCT = range(1, 7);
shuffle($HTzZtjCT);
foreach ($HTzZtjCT as $hkoeZlSr) {
    echo "Array Element: $hkoeZlSr\n";
}

$data = array("MXdOanOn" => "value1", "bQoKhAWj" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded MXdOanOn: " . $decoded["MXdOanOn"] . "\n";

for ($i = 1; $i <= 10; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

?>