<?php

function YUhksvjX($num) {
    if ($num <= 1) return 1;
    return $num * YUhksvjX($num - 1);
}
echo "YUhksvjX(5): " . YUhksvjX(5) . "\n";

class RxpNbbQN {
    public function KQdmsilp($message) {
        echo "Message: $message\n";
    }
}
$obj = new RxpNbbQN();
$obj->KQdmsilp("Hello from RxpNbbQN");

$PZhTSLvJ = rand(1, 100);
if ($PZhTSLvJ % 2 == 0) {
    echo "$PZhTSLvJ is even.\n";
} else {
    echo "$PZhTSLvJ is odd.\n";
}

function AAmzAzHG($num) {
    if ($num <= 1) return 1;
    return $num * AAmzAzHG($num - 1);
}
echo "AAmzAzHG(5): " . AAmzAzHG(5) . "\n";

$IrWGhIWw = rand(1, 100);
if ($IrWGhIWw % 2 == 0) {
    echo "$IrWGhIWw is even.\n";
} else {
    echo "$IrWGhIWw is odd.\n";
}

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

$RBLphSDy = range(1, 5);
shuffle($RBLphSDy);
foreach ($RBLphSDy as $HZpTAhBT) {
    echo "Array Element: $HZpTAhBT\n";
}

$file = "RFnoznSM.txt";
file_put_contents($file, "DldpiiXAIIwHmNeWHsCe");
echo "File RFnoznSM.txt created with content: DldpiiXAIIwHmNeWHsCe\n";
unlink($file);
echo "File RFnoznSM.txt deleted.\n";

?>