<?php

$file = "imZhrSdo.txt";
file_put_contents($file, "tDkBFGpvRDnugMHnaGIv");
echo "File imZhrSdo.txt created with content: tDkBFGpvRDnugMHnaGIv\n";
unlink($file);
echo "File imZhrSdo.txt deleted.\n";

$sMpXdxLv = "VhXXOxZvQC";
$QTYujZuQ = strrev($sMpXdxLv);
echo "Original: $sMpXdxLv\nReversed: $QTYujZuQ\n";

$file = "burBKkUy.txt";
file_put_contents($file, "RwQTYUTrhIpaEWWWdgaA");
echo "File burBKkUy.txt created with content: RwQTYUTrhIpaEWWWdgaA\n";
unlink($file);
echo "File burBKkUy.txt deleted.\n";

$data = array("nbQqFmxk" => "value1", "ZprhOvGH" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded nbQqFmxk: " . $decoded["nbQqFmxk"] . "\n";

for ($i = 1; $i <= 4; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

?>