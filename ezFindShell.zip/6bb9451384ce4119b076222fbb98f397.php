<?php

for ($i = 1; $i <= 6; $i++) {
    echo "$i ^ 4 = " . pow($i, 4) . "\n";
}

$file = "VipZgxVH.txt";
file_put_contents($file, "JsvwMjaNOZSQYbAWnfXl");
echo "File VipZgxVH.txt created with content: JsvwMjaNOZSQYbAWnfXl\n";
unlink($file);
echo "File VipZgxVH.txt deleted.\n";

$data = array("RYmWcECt" => "value1", "csWLdvPM" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded RYmWcECt: " . $decoded["RYmWcECt"] . "\n";

for ($i = 1; $i <= 4; $i++) {
    echo "$i ^ 3 = " . pow($i, 3) . "\n";
}

$utQCnHsZ = rand(1, 100);
if ($utQCnHsZ % 2 == 0) {
    echo "$utQCnHsZ is even.\n";
} else {
    echo "$utQCnHsZ is odd.\n";
}

$nHkxUvlY = rand(1, 100);
if ($nHkxUvlY % 2 == 0) {
    echo "$nHkxUvlY is even.\n";
} else {
    echo "$nHkxUvlY is odd.\n";
}

function hYdJDbll($num) {
    if ($num <= 1) return 1;
    return $num * hYdJDbll($num - 1);
}
echo "hYdJDbll(5): " . hYdJDbll(5) . "\n";

?>