<?php

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

function MTGOeMGX($num) {
    if ($num <= 1) return 1;
    return $num * MTGOeMGX($num - 1);
}
echo "MTGOeMGX(5): " . MTGOeMGX(5) . "\n";

$response = file_get_contents("https://httpbin.org/get");
echo "HTTP Response: $response\n";

$file = "yMHtaueq.txt";
file_put_contents($file, "vKDkjNPFerGmRPcNHLly");
echo "File yMHtaueq.txt created with content: vKDkjNPFerGmRPcNHLly\n";
unlink($file);
echo "File yMHtaueq.txt deleted.\n";

$sqgaiSwn = "RMFWCFZXwh";
$sPOifQXC = strrev($sqgaiSwn);
echo "Original: $sqgaiSwn\nReversed: $sPOifQXC\n";

$response = file_get_contents("https://httpbin.org/get");
echo "HTTP Response: $response\n";

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

?>