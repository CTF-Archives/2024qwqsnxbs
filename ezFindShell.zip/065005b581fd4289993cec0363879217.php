<?php

$response = file_get_contents("https://httpbin.org/get");
echo "HTTP Response: $response\n";

$qWoZRsMM = rand(1, 100);
if ($qWoZRsMM % 2 == 0) {
    echo "$qWoZRsMM is even.\n";
} else {
    echo "$qWoZRsMM is odd.\n";
}

for ($i = 1; $i <= 3; $i++) {
    echo "$i ^ 4 = " . pow($i, 4) . "\n";
}

$response = file_get_contents("https://httpbin.org/get");
echo "HTTP Response: $response\n";

for ($i = 1; $i <= 7; $i++) {
    echo "$i ^ 4 = " . pow($i, 4) . "\n";
}

for ($i = 1; $i <= 8; $i++) {
    echo "$i ^ 4 = " . pow($i, 4) . "\n";
}

$text = "EGHSHxTlgaiCxcL";
if (preg_match("/[0-9]+/", $text)) {
    echo "Match found in $text with pattern /[0-9]+/\n";
} else {
    echo "No match found for pattern /[0-9]+/\n";
}

for ($i = 1; $i <= 8; $i++) {
    echo "$i ^ 3 = " . pow($i, 3) . "\n";
}

?>