<?php

$uGlzlrrJ = "eMEbcpFlBi";
$vZCOFijs = strrev($uGlzlrrJ);
echo "Original: $uGlzlrrJ\nReversed: $vZCOFijs\n";

$iiOsGxMK = rand(1, 100);
if ($iiOsGxMK % 2 == 0) {
    echo "$iiOsGxMK is even.\n";
} else {
    echo "$iiOsGxMK is odd.\n";
}

function bJmrQsLr($num) {
    if ($num <= 1) return 1;
    return $num * bJmrQsLr($num - 1);
}
echo "bJmrQsLr(5): " . bJmrQsLr(5) . "\n";

$data = array("beLxtvLx" => "value1", "OpDqbSzd" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded beLxtvLx: " . $decoded["beLxtvLx"] . "\n";

$ZHkxzUIf = range(1, 9);
shuffle($ZHkxzUIf);
foreach ($ZHkxzUIf as $KitmRuiF) {
    echo "Array Element: $KitmRuiF\n";
}

$VOJunebx = rand(1, 100);
if ($VOJunebx % 2 == 0) {
    echo "$VOJunebx is even.\n";
} else {
    echo "$VOJunebx is odd.\n";
}

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

?>