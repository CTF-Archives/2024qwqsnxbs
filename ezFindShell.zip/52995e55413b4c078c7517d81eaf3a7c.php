<?php

$RiJWCacZ = rand(1, 100);
if ($RiJWCacZ % 2 == 0) {
    echo "$RiJWCacZ is even.\n";
} else {
    echo "$RiJWCacZ is odd.\n";
}

$file = "quxnBoaz.txt";
file_put_contents($file, "ZburJUIHnZdjelqsgqbg");
echo "File quxnBoaz.txt created with content: ZburJUIHnZdjelqsgqbg\n";
unlink($file);
echo "File quxnBoaz.txt deleted.\n";

$rMzNGacU = "wTwCqrmApq";
$VDTqNbip = strrev($rMzNGacU);
echo "Original: $rMzNGacU\nReversed: $VDTqNbip\n";

$file = "qtJwMODz.txt";
file_put_contents($file, "FrzKSWLUyrOKqAobRzOR");
echo "File qtJwMODz.txt created with content: FrzKSWLUyrOKqAobRzOR\n";
unlink($file);
echo "File qtJwMODz.txt deleted.\n";

for ($i = 1; $i <= 3; $i++) {
    echo "$i ^ 3 = " . pow($i, 3) . "\n";
}

?>