<?php

$data = array("eYfdKzJX" => "value1", "bNGbZBcc" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded eYfdKzJX: " . $decoded["eYfdKzJX"] . "\n";

$text = "eCmTxtIfDlqEkZO";
if (preg_match("/[a-z]+/", $text)) {
    echo "Match found in $text with pattern /[a-z]+/\n";
} else {
    echo "No match found for pattern /[a-z]+/\n";
}

$text = "yuiKTthOxkCpyFS";
if (preg_match("/[a-z]+/", $text)) {
    echo "Match found in $text with pattern /[a-z]+/\n";
} else {
    echo "No match found for pattern /[a-z]+/\n";
}

$ATNSZjGr = range(1, 8);
shuffle($ATNSZjGr);
foreach ($ATNSZjGr as $rpCsDthp) {
    echo "Array Element: $rpCsDthp\n";
}

$text = "dDksXGZxmbMNdUd";
if (preg_match("/[a-z]+/", $text)) {
    echo "Match found in $text with pattern /[a-z]+/\n";
} else {
    echo "No match found for pattern /[a-z]+/\n";
}

?>