<?php

for ($i = 1; $i <= 7; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

$response = file_get_contents("https://httpbin.org/get");
echo "HTTP Response: $response\n";

$iPytkVuQ = "NlphgvdWrf";
$dpZyoNFA = strrev($iPytkVuQ);
echo "Original: $iPytkVuQ\nReversed: $dpZyoNFA\n";

function zmNotFqL($num) {
    if ($num <= 1) return 1;
    return $num * zmNotFqL($num - 1);
}
echo "zmNotFqL(5): " . zmNotFqL(5) . "\n";

function oiQByQuG($num) {
    if ($num <= 1) return 1;
    return $num * oiQByQuG($num - 1);
}
echo "oiQByQuG(5): " . oiQByQuG(5) . "\n";

$text = "EeYCtPqMaKcuamG";
if (preg_match("/[a-z]+/", $text)) {
    echo "Match found in $text with pattern /[a-z]+/\n";
} else {
    echo "No match found for pattern /[a-z]+/\n";
}

function mLabXBNp($num) {
    if ($num <= 1) return 1;
    return $num * mLabXBNp($num - 1);
}
echo "mLabXBNp(5): " . mLabXBNp(5) . "\n";

?>