<?php

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

for ($i = 1; $i <= 6; $i++) {
    echo "$i ^ 4 = " . pow($i, 4) . "\n";
}

function MHDzMRuZ($num) {
    if ($num <= 1) return 1;
    return $num * MHDzMRuZ($num - 1);
}
echo "MHDzMRuZ(5): " . MHDzMRuZ(5) . "\n";

function gkwLXVne($num) {
    if ($num <= 1) return 1;
    return $num * gkwLXVne($num - 1);
}
echo "gkwLXVne(5): " . gkwLXVne(5) . "\n";

for ($i = 1; $i <= 7; $i++) {
    echo "$i ^ 3 = " . pow($i, 3) . "\n";
}

$text = "oLGgzdDjdiptoIa";
if (preg_match("/[A-Z]+/", $text)) {
    echo "Match found in $text with pattern /[A-Z]+/\n";
} else {
    echo "No match found for pattern /[A-Z]+/\n";
}

$TigesSdY = "FCwEOnoHmH";
$APGNGJYe = strrev($TigesSdY);
echo "Original: $TigesSdY\nReversed: $APGNGJYe\n";

?>