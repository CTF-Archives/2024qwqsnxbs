<?php

class DbnjnCre {
    public function xLAbwGff($message) {
        echo "Message: $message\n";
    }
}
$obj = new DbnjnCre();
$obj->xLAbwGff("Hello from DbnjnCre");

for ($i = 1; $i <= 4; $i++) {
    echo "$i ^ 4 = " . pow($i, 4) . "\n";
}

class iyxxTMsM {
    public function GKiVFLLp($message) {
        echo "Message: $message\n";
    }
}
$obj = new iyxxTMsM();
$obj->GKiVFLLp("Hello from iyxxTMsM");

$text = "muQdRJLYktPspeh";
if (preg_match("/[0-9]+/", $text)) {
    echo "Match found in $text with pattern /[0-9]+/\n";
} else {
    echo "No match found for pattern /[0-9]+/\n";
}

$text = "hHnkuxPvQHWSfGN";
if (preg_match("/[A-Z]+/", $text)) {
    echo "Match found in $text with pattern /[A-Z]+/\n";
} else {
    echo "No match found for pattern /[A-Z]+/\n";
}

?>