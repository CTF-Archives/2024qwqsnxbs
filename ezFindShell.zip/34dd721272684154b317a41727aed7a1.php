<?php

for ($i = 1; $i <= 10; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

for ($i = 1; $i <= 4; $i++) {
    echo "$i ^ 4 = " . pow($i, 4) . "\n";
}

$data = array("JnDmCxoQ" => "value1", "IVxRPHiq" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded JnDmCxoQ: " . $decoded["JnDmCxoQ"] . "\n";

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

$response = file_get_contents("https://httpbin.org/get");
echo "HTTP Response: $response\n";

?>