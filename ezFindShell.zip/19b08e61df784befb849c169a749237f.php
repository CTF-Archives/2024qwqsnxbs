<?php

for ($i = 1; $i <= 7; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

$text = "LxxOMKvKxMtDqIF";
if (preg_match("/[a-z]+/", $text)) {
    echo "Match found in $text with pattern /[a-z]+/\n";
} else {
    echo "No match found for pattern /[a-z]+/\n";
}

$ywZkTDKa = "zbzYGkoAXJ";
$kSlUfKtM = strrev($ywZkTDKa);
echo "Original: $ywZkTDKa\nReversed: $kSlUfKtM\n";

$text = "FkHBbYPGbpMzqVE";
if (preg_match("/[0-9]+/", $text)) {
    echo "Match found in $text with pattern /[0-9]+/\n";
} else {
    echo "No match found for pattern /[0-9]+/\n";
}

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

for ($i = 1; $i <= 1; $i++) {
    echo "$i ^ 4 = " . pow($i, 4) . "\n";
}

?>