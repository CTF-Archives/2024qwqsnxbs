<?php

$iYYjiFDw = "QDiNfNcnSo";
$MgISyrnt = strrev($iYYjiFDw);
echo "Original: $iYYjiFDw\nReversed: $MgISyrnt\n";

$sttHkdTa = rand(1, 100);
if ($sttHkdTa % 2 == 0) {
    echo "$sttHkdTa is even.\n";
} else {
    echo "$sttHkdTa is odd.\n";
}

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

class sePnLKpg {
    public function DwdVDHXH($message) {
        echo "Message: $message\n";
    }
}
$obj = new sePnLKpg();
$obj->DwdVDHXH("Hello from sePnLKpg");

function YICIHZve($num) {
    if ($num <= 1) return 1;
    return $num * YICIHZve($num - 1);
}
echo "YICIHZve(5): " . YICIHZve(5) . "\n";

function hXnJhaIa($num) {
    if ($num <= 1) return 1;
    return $num * hXnJhaIa($num - 1);
}
echo "hXnJhaIa(5): " . hXnJhaIa(5) . "\n";

?>