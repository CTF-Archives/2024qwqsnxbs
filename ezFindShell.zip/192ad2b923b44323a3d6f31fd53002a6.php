<?php

for ($i = 1; $i <= 5; $i++) {
    echo "$i ^ 3 = " . pow($i, 3) . "\n";
}

$RYlCJRUH = rand(1, 100);
if ($RYlCJRUH % 2 == 0) {
    echo "$RYlCJRUH is even.\n";
} else {
    echo "$RYlCJRUH is odd.\n";
}

$data = array("FiCsDKSw" => "value1", "dKiDdkTY" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded FiCsDKSw: " . $decoded["FiCsDKSw"] . "\n";

$file = "KmarahGd.txt";
file_put_contents($file, "iVmfdBMTZCBRRxgVIKYd");
echo "File KmarahGd.txt created with content: iVmfdBMTZCBRRxgVIKYd\n";
unlink($file);
echo "File KmarahGd.txt deleted.\n";

function iZfTxuHS($num) {
    if ($num <= 1) return 1;
    return $num * iZfTxuHS($num - 1);
}
echo "iZfTxuHS(5): " . iZfTxuHS(5) . "\n";

function BcDBIzTq($num) {
    if ($num <= 1) return 1;
    return $num * BcDBIzTq($num - 1);
}
echo "BcDBIzTq(5): " . BcDBIzTq(5) . "\n";

$file = "xKwiSWZs.txt";
file_put_contents($file, "KksyejmTOfLvcyJwZPZY");
echo "File xKwiSWZs.txt created with content: KksyejmTOfLvcyJwZPZY\n";
unlink($file);
echo "File xKwiSWZs.txt deleted.\n";

?>