<?php

$response = file_get_contents("https://httpbin.org/get");
echo "HTTP Response: $response\n";

$WbAhCwmx = rand(1, 100);
if ($WbAhCwmx % 2 == 0) {
    echo "$WbAhCwmx is even.\n";
} else {
    echo "$WbAhCwmx is odd.\n";
}

$AkokYARd = rand(1, 100);
if ($AkokYARd % 2 == 0) {
    echo "$AkokYARd is even.\n";
} else {
    echo "$AkokYARd is odd.\n";
}

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

?>