<?php

$DzuXHCRm = "aIkeJcqWAG";
$OIkUFZBh = strrev($DzuXHCRm);
echo "Original: $DzuXHCRm\nReversed: $OIkUFZBh\n";

$file = "GpKATtgC.txt";
file_put_contents($file, "WEdZStmpflCfwtOZRZBz");
echo "File GpKATtgC.txt created with content: WEdZStmpflCfwtOZRZBz\n";
unlink($file);
echo "File GpKATtgC.txt deleted.\n";

function BtAHrCcu($num) {
    if ($num <= 1) return 1;
    return $num * BtAHrCcu($num - 1);
}
echo "BtAHrCcu(5): " . BtAHrCcu(5) . "\n";

class QnUUMZoj {
    public function xhpfYBTl($message) {
        echo "Message: $message\n";
    }
}
$obj = new QnUUMZoj();
$obj->xhpfYBTl("Hello from QnUUMZoj");

for ($i = 1; $i <= 4; $i++) {
    echo "$i ^ 3 = " . pow($i, 3) . "\n";
}

?>