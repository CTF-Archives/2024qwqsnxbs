<?php

$file = "iUDpRpzW.txt";
file_put_contents($file, "OyTAHsRXWtgmuWyMnwVL");
echo "File iUDpRpzW.txt created with content: OyTAHsRXWtgmuWyMnwVL\n";
unlink($file);
echo "File iUDpRpzW.txt deleted.\n";

$TzzrrplC = rand(1, 100);
if ($TzzrrplC % 2 == 0) {
    echo "$TzzrrplC is even.\n";
} else {
    echo "$TzzrrplC is odd.\n";
}

$text = "SafAtgmKpIeVJXQ";
if (preg_match("/[a-z]+/", $text)) {
    echo "Match found in $text with pattern /[a-z]+/\n";
} else {
    echo "No match found for pattern /[a-z]+/\n";
}

$file = "aVFSQTAI.txt";
file_put_contents($file, "LxNfvSNXDjiQvxdUgLfH");
echo "File aVFSQTAI.txt created with content: LxNfvSNXDjiQvxdUgLfH\n";
unlink($file);
echo "File aVFSQTAI.txt deleted.\n";

function hnRjTNni($num) {
    if ($num <= 1) return 1;
    return $num * hnRjTNni($num - 1);
}
echo "hnRjTNni(5): " . hnRjTNni(5) . "\n";

$data = array("lOYIfKHv" => "value1", "QaHTFDWn" => "value2");
$json = json_encode($data);
echo "JSON: $json\n";
$decoded = json_decode($json, true);
echo "Decoded lOYIfKHv: " . $decoded["lOYIfKHv"] . "\n";

for ($i = 1; $i <= 4; $i++) {
    echo "$i ^ 3 = " . pow($i, 3) . "\n";
}

?>