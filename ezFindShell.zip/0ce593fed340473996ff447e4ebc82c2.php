<?php

$NSFbbZax = rand(1, 100);
if ($NSFbbZax % 2 == 0) {
    echo "$NSFbbZax is even.\n";
} else {
    echo "$NSFbbZax is odd.\n";
}

echo "Current Date: " . date("Y-m-d") . "\n";
echo "Current Time: " . date("H:i:s") . "\n";

$file = "TevbeMxt.txt";
file_put_contents($file, "iAhVuCPOJJcftMqrRufM");
echo "File TevbeMxt.txt created with content: iAhVuCPOJJcftMqrRufM\n";
unlink($file);
echo "File TevbeMxt.txt deleted.\n";

$HKNeyzOp = range(1, 10);
shuffle($HKNeyzOp);
foreach ($HKNeyzOp as $OCNhzqyU) {
    echo "Array Element: $OCNhzqyU\n";
}

for ($i = 1; $i <= 9; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

?>