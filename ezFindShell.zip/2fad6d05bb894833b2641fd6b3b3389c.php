<?php

for ($i = 1; $i <= 3; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

class yXutQBoR {
    public function XFJlRmbr($message) {
        echo "Message: $message\n";
    }
}
$obj = new yXutQBoR();
$obj->XFJlRmbr("Hello from yXutQBoR");

$JCogptnR = range(1, 15);
shuffle($JCogptnR);
foreach ($JCogptnR as $XxJyQaVs) {
    echo "Array Element: $XxJyQaVs\n";
}

class EKlSKjWS {
    public function IKKpcgNl($message) {
        echo "Message: $message\n";
    }
}
$obj = new EKlSKjWS();
$obj->IKKpcgNl("Hello from EKlSKjWS");

for ($i = 1; $i <= 9; $i++) {
    echo "$i ^ 3 = " . pow($i, 3) . "\n";
}

function qSBfMHAn($num) {
    if ($num <= 1) return 1;
    return $num * qSBfMHAn($num - 1);
}
echo "qSBfMHAn(5): " . qSBfMHAn(5) . "\n";

$text = "fIVXTkUSvPwxhZl";
if (preg_match("/[0-9]+/", $text)) {
    echo "Match found in $text with pattern /[0-9]+/\n";
} else {
    echo "No match found for pattern /[0-9]+/\n";
}

for ($i = 1; $i <= 8; $i++) {
    echo "$i ^ 3 = " . pow($i, 3) . "\n";
}

?>