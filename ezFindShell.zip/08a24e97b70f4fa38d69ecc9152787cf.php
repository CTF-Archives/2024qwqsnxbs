<?php

for ($i = 1; $i <= 6; $i++) {
    echo "$i ^ 2 = " . pow($i, 2) . "\n";
}

function LoexxXDy($num) {
    if ($num <= 1) return 1;
    return $num * LoexxXDy($num - 1);
}
echo "LoexxXDy(5): " . LoexxXDy(5) . "\n";

$file = "WnuoLhXV.txt";
file_put_contents($file, "VNMTqvZPNEfiOMLwlKBU");
echo "File WnuoLhXV.txt created with content: VNMTqvZPNEfiOMLwlKBU\n";
unlink($file);
echo "File WnuoLhXV.txt deleted.\n";

$uLIYuQSh = rand(1, 100);
if ($uLIYuQSh % 2 == 0) {
    echo "$uLIYuQSh is even.\n";
} else {
    echo "$uLIYuQSh is odd.\n";
}

$ZTrtAFcW = "lGjPzZgpHn";
$SRbkOuhC = strrev($ZTrtAFcW);
echo "Original: $ZTrtAFcW\nReversed: $SRbkOuhC\n";

$text = "BaLSHSAzPjUGWhT";
if (preg_match("/[A-Z]+/", $text)) {
    echo "Match found in $text with pattern /[A-Z]+/\n";
} else {
    echo "No match found for pattern /[A-Z]+/\n";
}

$response = file_get_contents("https://httpbin.org/get");
echo "HTTP Response: $response\n";

$response = file_get_contents("https://httpbin.org/get");
echo "HTTP Response: $response\n";

?>